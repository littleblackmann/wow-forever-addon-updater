-- Local Traditional Chinese additions, separate from author locale files.
if GetLocale() ~= "zhTW" then return end
local L = BAGANATOR_LOCALES.zhTW
L["DEVELOPMENT_IS_DONE_BY_A_HUMAN"] = "|cff04cca4由用心的人類開發者製作（未使用 AI）|r"
L["CANNOT_OPEN_BAGS_IN_COMBAT"] = "戰鬥中無法開啟背包"

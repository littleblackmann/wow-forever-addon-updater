-- Local Traditional Chinese additions; author locale files remain unchanged.
if GetLocale() ~= "zhTW" then return end
local L = PLATYNATOR_LOCALES.zhTW
L["GROUP"] = "隊伍"
L["GROUPED"] = "已組隊"
L["SHOW_FIRST_NAME_ONLY"] = "只顯示名字的第一部分"

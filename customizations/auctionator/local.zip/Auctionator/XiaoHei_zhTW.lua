-- Local Traditional Chinese additions, separate from author locale files.
if GetLocale() ~= "zhTW" then return end
local original = AUCTIONATOR_LOCALES.zhTW
AUCTIONATOR_LOCALES.zhTW = function()
    local L = original()
    L["PAST_AUTHOR_HEADER"] = "歷任作者"
    L["SUPPORT_HEADER"] = "取得協助"
    return L
end

local ADDON, Hub = ...
local nodes, order, initial = {}, {}, {}
local character

-- These authors use optional load order and report a missing companion themselves.
local required = { baganator = "Syndicator", shortestpathforever = "ForeverCore" }

local function managed(name)
    return name ~= ADDON:lower() and not name:match("^blizzard_")
end

local function state(name)
    if not character or not C_AddOns or type(C_AddOns.GetAddOnEnableState) ~= "function" then return end
    local ok, value = pcall(C_AddOns.GetAddOnEnableState, name, character)
    if ok and type(value) == "number" then return value > 0 end
end

function Hub.Scan()
    local usable = character and C_AddOns and type(C_AddOns.GetNumAddOns) == "function"
        and type(C_AddOns.GetAddOnInfo) == "function" and type(C_AddOns.GetAddOnDependencies) == "function"
    if not usable then return end
    nodes, order = {}, {}
    for index = 1, C_AddOns.GetNumAddOns() do
        local name = C_AddOns.GetAddOnInfo(index)
        if type(name) == "string" then
            local key = name:lower()
            local deps = { C_AddOns.GetAddOnDependencies(index) }
            if required[key] and not (key == "shortestpathforever" and Hub.HasEmbeddedForeverCore(index)) then
                deps[#deps + 1] = required[key]
            end
            for i, dep in ipairs(deps) do deps[i] = dep:lower() end
            nodes[key] = { name = name, deps = deps, managed = managed(key) }
        end
    end
    local visited = {}
    local function visit(key)
        if visited[key] or not nodes[key] then return end
        visited[key] = true
        for _, dep in ipairs(nodes[key].deps) do visit(dep) end
        order[#order + 1] = key
    end
    local keys = {}
    for key in pairs(nodes) do keys[#keys + 1] = key end
    table.sort(keys)
    for _, key in ipairs(keys) do visit(key) end
end

local function snapshot()
    local result = {}
    for _, key in ipairs(order) do result[key] = state(nodes[key].name) end
    return result
end

function Hub.CanChange()
    return character and C_AddOns and type(C_AddOns.EnableAddOn) == "function"
        and type(C_AddOns.DisableAddOn) == "function" and type(C_AddOns.SaveAddOns) == "function"
        and type(C_AddOns.GetAddOnDependencies) == "function"
end

local function blocked()
    if InCombatLockdown() then return "戰鬥結束後再調整插件。" end
    if not Hub.CanChange() then return "目前無法讀寫角色的插件設定。" end
end

function Hub.EntryState(entry)
    local anchor = state(entry.name)
    for _, name in ipairs(entry.members) do
        local member = state(name)
        if member == nil then return nil end
        if member ~= anchor then return anchor, true end
    end
    return anchor, false
end

function Hub.HasChanges()
    for key, value in pairs(snapshot()) do
        if nodes[key].managed and initial[key] ~= nil and initial[key] ~= value then return true end
    end
    return false
end

local function restoreOrWrite(desired)
    local function write(key, value)
        local action = value and C_AddOns.EnableAddOn or C_AddOns.DisableAddOn
        local ok = pcall(action, nodes[key].name, character)
        return ok and state(nodes[key].name) == value
    end
    for i = #order, 1, -1 do
        local key = order[i]
        if desired[key] == false and state(nodes[key].name) ~= false and not write(key, false) then return false end
    end
    for _, key in ipairs(order) do
        if desired[key] == true and state(nodes[key].name) ~= true and not write(key, true) then return false end
    end
    if not pcall(C_AddOns.SaveAddOns) then return false end
    for key, value in pairs(desired) do
        if state(nodes[key].name) ~= value then return false end
    end
    return true
end

local function update(target, before)
    local function requireState(key, from)
        local node = nodes[key]
        if not node or before[key] == nil or (not node.managed and not before[key]) then
            return "無法啟用「" .. from .. "」，請先確認所需元件「" .. (node and node.name or key) .. "」。"
        end
        if target[key] ~= nil then return end
        if not node.managed then return end
        target[key] = true
        for _, dep in ipairs(node.deps) do
            local problem = requireState(dep, node.name)
            if problem then return problem end
        end
        if not before[key] then
            for _, member in ipairs(Hub.BundleMembers(node.name) or {}) do
                local memberKey = member:lower()
                if nodes[memberKey] then
                    local problem = requireState(memberKey, node.name)
                    if problem then return problem end
                end
            end
        end
    end

    -- The profile can contain both enabled and disabled addons. An explicit
    -- disable takes priority over any addon that needs that dependency.
    for _, key in ipairs(order) do
        if target[key] == true then
            for _, dep in ipairs(nodes[key].deps) do
                local problem = requireState(dep, nodes[key].name)
                if problem then return false, problem end
            end
        end
    end
    for _, key in ipairs(order) do
        local node = nodes[key]
        if target[key] == true or (target[key] == nil and before[key]) then
            for _, dep in ipairs(node.deps) do
                if target[dep] == false then
                    if not node.managed then return false, "這項變更會影響遊戲元件「" .. node.name .. "」。" end
                    target[key] = false
                    break
                end
            end
        end
    end

    local changed, rollback = {}, {}
    for _, key in ipairs(order) do
        if target[key] ~= nil and target[key] ~= before[key] then
            if before[key] == nil then return false, "讀不到「" .. nodes[key].name .. "」的啟用狀態。" end
            rollback[key] = before[key]
            changed[#changed + 1] = nodes[key].name
        end
    end
    if #changed == 0 then return true, nil, changed end
    if not restoreOrWrite(target) then
        if restoreOrWrite(rollback) then return false, "遊戲未接受這次變更，已還原。" end
        return false, "遊戲未能儲存或還原部分變更，請核對目前的勾選狀態。"
    end
    return true, nil, changed
end

local function profileDB()
    local db = XiaoHeiAddonHubDB
    if type(db.scheme) ~= "table" then db.scheme = {} end
    if type(db.scheme.optIn) ~= "table" then db.scheme.optIn = {} end
    if type(db.scheme.applied) ~= "table" then db.scheme.applied = {} end
    return db.scheme
end

local function remember()
    local profile = profileDB()
    if not character or profile.owner ~= character or profile.remember ~= true then return end
    local nextState = {}
    for key, value in pairs(snapshot()) do
        if nodes[key].managed then nextState[key] = value end
    end
    if not next(nextState) then return end
    local old = profile.states
    if type(old) == "table" then
        local equal = true
        for key, value in pairs(nextState) do if old[key] ~= value then equal = false break end end
        if equal then
            for key in pairs(old) do if nextState[key] == nil then equal = false break end end
        end
        if equal then return end
    end
    profile.states = nextState
    profile.revision = (tonumber(profile.revision) or 0) + 1
end

function Hub.Turn(entry, enabled)
    local reason = blocked()
    if reason then return false, reason end
    local target = {}
    for _, name in ipairs(entry.members) do
        local key = name:lower()
        if not nodes[key] or not nodes[key].managed then return false, "這個插件無法由總入口切換。" end
        target[key] = enabled
    end
    local ok, message, changed = update(target, snapshot())
    if ok then remember() end
    return ok, message, changed
end

function Hub.ProfileInfo()
    local profile = profileDB()
    local owner = character and profile.owner == character
    local exists = type(profile.states) == "table" and next(profile.states) ~= nil
    return exists and profile.ownerName or nil, owner and profile.remember == true,
        not owner and profile.optIn[character] == true, exists and not owner
end

function Hub.Remember(enabled)
    local reason = blocked()
    if reason then return false, reason end
    local profile = profileDB()
    if enabled then
        profile.owner = character
        profile.ownerName = UnitName("player") or "目前角色"
        profile.optIn[character] = nil
        profile.remember = true
        remember()
    elseif profile.owner == character then
        profile.remember = false
    end
    return true
end

function Hub.SetAuto(enabled)
    local reason = blocked()
    if reason then return false, reason end
    local profile = profileDB()
    if profile.owner == character or type(profile.states) ~= "table" then return false, "請先記住主角色的插件方案。" end
    profile.optIn[character] = enabled and true or nil
    -- If the player opts in again, apply even if the revision is unchanged.
    profile.applied[character] = nil
    return true
end

function Hub.ApplyProfile(automatic)
    local profile = profileDB()
    if not character or profile.owner == character or type(profile.states) ~= "table" then return true end
    if automatic and (not profile.optIn[character] or profile.applied[character] == profile.revision) then return true end
    local reason = blocked()
    if reason then return false, reason end
    local target = {}
    for key, value in pairs(profile.states) do
        if type(value) == "boolean" and nodes[key] and nodes[key].managed then target[key] = value end
    end
    local ok, message, changed = update(target, snapshot())
    if ok then profile.applied[character] = profile.revision end
    return ok, message, changed
end

function Hub.InitCharacter()
    character = UnitGUID("player")
    Hub.Scan()
    initial = snapshot()
    remember()
end

function Hub.Reload()
    if InCombatLockdown() then return false, "戰鬥結束後再重新載入。" end
    if type(ReloadUI) ~= "function" then return false, "目前無法重新載入遊戲介面。" end
    remember()
    ReloadUI()
    return true
end

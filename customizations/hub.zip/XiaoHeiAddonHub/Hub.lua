local _, Hub = ...
local button, pendingProfile

function Hub.Say(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffe3bc76小黑插件總入口|r " .. message) end
end

function Hub.Tooltip(owner, title, lines)
    GameTooltip:SetOwner(owner, "ANCHOR_LEFT")
    GameTooltip:SetText(title, 1, 0.82, 0)
    for _, line in ipairs(lines) do GameTooltip:AddLine(line, 0.85, 0.85, 0.85, true) end
    GameTooltip:Show()
end

local function placeButton()
    if not button then return end
    local scale = Minimap:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local angle = math.rad(XiaoHeiAddonHubDB.angle)
    local radiusX = Minimap:GetWidth() * scale / 2 + 7
    local radiusY = Minimap:GetHeight() * scale / 2 + 7
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radiusX, math.sin(angle) * radiusY)
end

local function createButton()
    -- Parent to UIParent and anchor to Minimap: existing button collectors won't
    -- swallow this top-level launcher. No changes to other addons' preferences.
    button = CreateFrame("Button", "XiaoHeiAddonHubButton", UIParent)
    button:SetSize(32, 32)
    button:SetFrameStrata("HIGH")
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(25, 25)
    bg:SetPoint("CENTER")
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    if button.CreateMaskTexture and icon.AddMaskTexture then
        local mask = button:CreateMaskTexture()
        mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        mask:SetAllPoints(icon)
        icon:AddMaskTexture(mask)
    end
    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT", button, "CENTER", -16, 16)
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight", "ADD")
    button:SetScript("OnClick", function() Hub.Toggle() end)
    button:SetScript("OnEnter", function(self) Hub.Tooltip(self, "小黑插件總入口", {"點一下：選擇插件與設定", "Shift + 拖曳：沿小地圖移動", "也可輸入 /插件 或 /xhub"}) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnDragStart", function(self)
        if not IsShiftKeyDown() then return end
        GameTooltip:Hide()
        self:SetScript("OnUpdate", function()
            local x, y = GetCursorPosition()
            local cx, cy = Minimap:GetCenter()
            local scale = Minimap:GetEffectiveScale()
            local dx, dy = x - cx * scale, y - cy * scale
            XiaoHeiAddonHubDB.angle = math.deg(math.atan2(dy, dx)) % 360
            placeButton()
        end)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    Minimap:HookScript("OnHide", function() button:Hide() end)
    Minimap:HookScript("OnShow", function() button:Show() placeButton() end)
    Minimap:HookScript("OnSizeChanged", placeButton)
    if not Minimap:IsShown() then button:Hide() end
    placeButton()
end

local function applyAutomaticProfile()
    local ok, message, changed = Hub.ApplyProfile(true)
    if not ok then
        Hub.Say(message)
    elseif changed and #changed > 0 then
        Hub.Say("已套用共用插件方案。開啟小黑插件總入口，再按「重新載入」即可生效。")
    end
end

local function preferTraditionalChinese()
    local db = XiaoHeiAddonHubDB
    if db.lueurLanguageInitialized or InCombatLockdown() or not C_AddOns.IsAddOnLoaded("Lueur") then return end
    local settings = _G.LueurDB
    local version = C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata("Lueur", "Version")
    local command = SlashCmdList.LUEUR
    if type(settings) ~= "table" or type(settings.language) ~= "string"
        or type(version) ~= "string" or not version:match("^2%.") or type(command) ~= "function" then return end
    if settings.language == "auto" and GetLocale() ~= "zhTW" then
        local applied = pcall(command, "language zhTW")
        if not applied or settings.language ~= "zhTW" then return end
    end
    db.lueurLanguageInitialized = true
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        if type(XiaoHeiAddonHubDB) ~= "table" then XiaoHeiAddonHubDB = {} end
        local angle = tonumber(XiaoHeiAddonHubDB.angle)
        XiaoHeiAddonHubDB.angle = (angle and angle == angle and angle > -math.huge and angle < math.huge) and angle % 360 or 225
        Hub.InitCharacter()
        if Minimap then createButton() end
        SLASH_XIAOHEIADDONHUB1 = "/xhub"
        SLASH_XIAOHEIADDONHUB2 = "/插件"
        SlashCmdList.XIAOHEIADDONHUB = Hub.Toggle
        if C_Timer and C_Timer.After then C_Timer.After(2, placeButton) end
        pendingProfile = InCombatLockdown()
        if not pendingProfile then
            applyAutomaticProfile()
            preferTraditionalChinese()
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        Hub.ClosePanel()
        if button then button:SetScript("OnUpdate", nil) end
    elseif pendingProfile then
        pendingProfile = nil
        applyAutomaticProfile()
        preferTraditionalChinese()
    end
end)

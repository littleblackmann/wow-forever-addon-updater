local ADDON, Hub = ...
local panel, button, search, rows, countText, pageText, previous, nextPage, hint
local page, entries = 1, {}
local PAGE_SIZE = 8

local function say(text)
    print("|cffffd18a小黑插件總入口|r：" .. text)
end

local function font(parent, template, point, x, y, text)
    local label = parent:CreateFontString(nil, "OVERLAY", template)
    label:SetPoint(point, parent, point, x, y)
    label:SetText(text or "")
    return label
end

local function tooltip(owner, title, lines)
    GameTooltip:SetOwner(owner, "ANCHOR_LEFT")
    GameTooltip:SetText(title, 1, 0.82, 0)
    for _, line in ipairs(lines) do GameTooltip:AddLine(line, 0.85, 0.85, 0.85, true) end
    GameTooltip:Show()
end

local function placeButton()
    if not button then return end
    local scale = Minimap:GetEffectiveScale() / UIParent:GetEffectiveScale()
    local angle = math.rad(XiaoHeiAddonHubDB.angle)
    local radiusX = Minimap:GetWidth() * scale / 2 + 7
    local radiusY = Minimap:GetHeight() * scale / 2 + 7
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radiusX, math.sin(angle) * radiusY)
end

local function refresh(rescan)
    if rescan then entries = Hub.Collect() end
    local filtered = Hub.Filter(entries, search:GetText())
    local pages = math.max(1, math.ceil(#filtered / PAGE_SIZE))
    page = math.max(1, math.min(page, pages))
    local loaded = 0
    for _, entry in ipairs(entries) do if entry.loaded then loaded = loaded + 1 end end
    countText:SetText(("已載入 %d / %d 個插件 · 符合搜尋 %d 個"):format(loaded, #entries, #filtered))
    for i, row in ipairs(rows) do
        local entry = filtered[(page - 1) * PAGE_SIZE + i]
        row.entry = entry
        if entry then
            row:Show()
            row.icon:SetTexture(entry.icon)
            row.label:SetText(entry.label)
            row.detail:SetText(entry.detail)
            local launch = Hub.Resolve(entry)
            row.action:SetText(launch and (entry.adapter.action or "設定") or (entry.loaded and "說明" or "未載入"))
            row.action:SetEnabled(entry.loaded)
            row:SetAlpha(entry.loaded and 1 or 0.5)
        else row:Hide() end
    end
    pageText:SetText(("%d / %d"):format(page, pages))
    previous:SetEnabled(page > 1)
    nextPage:SetEnabled(page < pages)
    hint:SetText(#filtered == 0 and "找不到符合的插件，試試中文用途或英文名稱。" or "選擇插件開啟設定；新增插件後可重新整理。")
end

local function activate(row)
    if not row.entry then return end
    if InCombatLockdown() then say("戰鬥結束後再開啟插件設定。") return end
    local launch, reason = Hub.Resolve(row.entry)
    if not launch then
        hint:SetText(reason)
        say(row.entry.label .. "：" .. reason)
        return
    end
    -- Hide first so the addon's own window receives keyboard focus.
    panel:Hide()
    local ok, message = Hub.Open(row.entry)
    if not ok then panel:Show() hint:SetText(message) say(message) end
end

local function createPanel()
    local ok, frame = pcall(CreateFrame, "Frame", "XiaoHeiAddonHubWindow", UIParent, "BasicFrameTemplateWithInset")
    panel = ok and frame or CreateFrame("Frame", "XiaoHeiAddonHubWindow", UIParent, "BackdropTemplate")
    panel:SetSize(492, 650)
    panel:SetScale(math.min(1, (UIParent:GetHeight() - 64) / 650, (UIParent:GetWidth() - 32) / 492))
    panel:SetPoint("CENTER")
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
    panel:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    if panel.TitleText then panel.TitleText:SetText("小黑插件總入口")
    else
        panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=8,right=8,top=8,bottom=8}})
        font(panel, "GameFontNormalLarge", "TOP", 0, -16, "小黑插件總入口")
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -3, -3)
    end
    panel:Hide()
    UISpecialFrames[#UISpecialFrames + 1] = "XiaoHeiAddonHubWindow"

    font(panel, "GameFontNormalLarge", "TOPLEFT", 22, -43, "你的插件，集中在這裡。")
    font(panel, "GameFontHighlightSmall", "TOPLEFT", 22, -68, "找設定、看功能，不用再記一串指令。")
    search = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    search:SetSize(316, 25)
    search:SetPoint("TOPLEFT", 28, -96)
    search:SetAutoFocus(false)
    search:SetMaxLetters(80)
    search:SetScript("OnTextChanged", function() page = 1 refresh(false) end)
    search:SetScript("OnEscapePressed", function(self) self:ClearFocus() panel:Hide() end)
    search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    search:SetScript("OnEnter", function(self) tooltip(self, "搜尋插件", {"輸入中文用途或英文插件名稱。", "清空搜尋欄即可顯示全部。"}) end)
    search:SetScript("OnLeave", function() GameTooltip:Hide() end)
    local reload = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    reload:SetSize(106, 25)
    reload:SetPoint("TOPRIGHT", -22, -96)
    reload:SetText("重新整理")
    reload:SetScript("OnClick", function() page = 1 refresh(true) end)
    countText = font(panel, "GameFontHighlightSmall", "TOPLEFT", 22, -132)
    rows = {}
    for i = 1, PAGE_SIZE do
        local row = CreateFrame("Frame", nil, panel)
        row:SetSize(448, 49)
        row:SetPoint("TOPLEFT", 22, -154 - (i - 1) * 49)
        row:EnableMouse(true)
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.22, 0.17, 0.08, i % 2 == 0 and 0.15 or 0.35)
        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(30, 30)
        row.icon:SetPoint("LEFT", 7, 0)
        row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.label = font(row, "GameFontNormal", "TOPLEFT", 47, -8)
        row.label:SetWidth(307)
        row.label:SetJustifyH("LEFT")
        row.detail = font(row, "GameFontHighlightSmall", "TOPLEFT", 47, -27)
        row.detail:SetWidth(307)
        row.detail:SetWordWrap(false)
        row.detail:SetJustifyH("LEFT")
        row.action = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.action:SetSize(72, 26)
        row.action:SetPoint("RIGHT", -5, 0)
        row.action:SetScript("OnClick", function() activate(row) end)
        row:SetScript("OnEnter", function(self)
            if self.entry then
                local _, reason = Hub.Resolve(self.entry)
                tooltip(self, self.entry.label, {self.entry.name, self.entry.notes, reason or "點右側按鈕開啟。"})
            end
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        rows[i] = row
    end
    previous = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    previous:SetSize(75, 24)
    previous:SetPoint("BOTTOMLEFT", 22, 66)
    previous:SetText("上一頁")
    previous:SetScript("OnClick", function() page = page - 1 refresh(false) end)
    nextPage = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    nextPage:SetSize(75, 24)
    nextPage:SetPoint("LEFT", previous, "RIGHT", 8, 0)
    nextPage:SetText("下一頁")
    nextPage:SetScript("OnClick", function() page = page + 1 refresh(false) end)
    pageText = font(panel, "GameFontHighlightSmall", "BOTTOM", 0, 74)
    local settings = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    settings:SetSize(126, 24)
    settings:SetPoint("BOTTOMRIGHT", -22, 66)
    settings:SetText("遊戲插件清單")
    settings:SetScript("OnClick", function()
        if InCombatLockdown() then say("戰鬥結束後再開啟插件清單。") return end
        if AddonList then panel:Hide() ShowUIPanel(AddonList)
        else hint:SetText("按 Esc → 插件，可查看載入狀態。") end
    end)
    hint = font(panel, "GameFontHighlightSmall", "BOTTOMLEFT", 22, 26)
    hint:SetWidth(448)
    hint:SetJustifyH("LEFT")
    panel:SetScript("OnShow", function() refresh(true) end)
    panel:SetScript("OnHide", function() search:ClearFocus() GameTooltip:Hide() end)
end

function Hub.Toggle()
    if InCombatLockdown() then say("戰鬥結束後再開啟插件選單。") return end
    if not panel then createPanel() end
    panel:SetShown(not panel:IsShown())
end

local function createButton()
    -- Parent to UIParent and anchor to Minimap: existing button collectors won't
    -- swallow this top-level launcher. No changes to other addons' preferences.
    button = CreateFrame("Button", "XiaoHeiAddonHubButton", UIParent)
    button:SetSize(32, 32)
    button:SetFrameStrata("HIGH")
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(25, 25)
    bg:SetPoint("CENTER")
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    if button.CreateMaskTexture and icon.AddMaskTexture then
        local mask = button:CreateMaskTexture()
        mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        mask:SetAllPoints(icon)
        icon:AddMaskTexture(mask)
    end
    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT", button, "CENTER", -16, 16)
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight", "ADD")
    button:SetScript("OnClick", function() Hub.Toggle() end)
    button:SetScript("OnEnter", function(self) tooltip(self, "小黑插件總入口", {"點一下：選擇插件與設定", "Shift + 拖曳：沿小地圖移動", "也可輸入 /插件 或 /xhub"}) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnDragStart", function(self)
        if not IsShiftKeyDown() then return end
        GameTooltip:Hide()
        self:SetScript("OnUpdate", function()
            local x, y = GetCursorPosition()
            local cx, cy = Minimap:GetCenter()
            local scale = Minimap:GetEffectiveScale()
            local dx, dy = x - cx * scale, y - cy * scale
            XiaoHeiAddonHubDB.angle = math.deg(math.atan2(dy, dx)) % 360
            placeButton()
        end)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    Minimap:HookScript("OnHide", function() button:Hide() end)
    Minimap:HookScript("OnShow", function() button:Show() placeButton() end)
    Minimap:HookScript("OnSizeChanged", placeButton)
    if not Minimap:IsShown() then button:Hide() end
    placeButton()
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        if type(XiaoHeiAddonHubDB) ~= "table" then XiaoHeiAddonHubDB = {} end
        local angle = tonumber(XiaoHeiAddonHubDB.angle)
        XiaoHeiAddonHubDB.angle = (angle and angle == angle and angle > -math.huge and angle < math.huge) and angle % 360 or 225
        if Minimap then createButton() end
        SLASH_XIAOHEIADDONHUB1 = "/xhub"
        SLASH_XIAOHEIADDONHUB2 = "/插件"
        SlashCmdList.XIAOHEIADDONHUB = Hub.Toggle
        if C_Timer and C_Timer.After then C_Timer.After(2, placeButton) end
    elseif event == "PLAYER_REGEN_DISABLED" then
        if panel then panel:Hide() end
        if button then button:SetScript("OnUpdate", nil) end
    end
end)

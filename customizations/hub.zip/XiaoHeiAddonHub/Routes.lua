local ADDON, Hub = ...

local known = {
    Questie = {area="quests", label="任務助手", notes="在地圖標出任務目標，並自訂任務追蹤與提示。", slash="ACECONSOLE_QUESTIE", icon="INV_Misc_QuestionMark"},
    QuestieDB = {area="quests", label="路線地點資料庫", notes="提供最短路線查詢附近的飛行點、商人與其他服務。此資料庫沒有獨立設定視窗。", data=true, icon="INV_Misc_Book_11"},
    DialogueUI = {area="quests", label="任務對話介面", display="Dialogue UI", notes="調整任務文字、對話外觀與鏡頭。", open="DialogueUI_ShowSettingsFrame", icon="INV_Scroll_03"},
    WhatsTraining = {area="quests", label="技能學習清單", display="What's Training", notes="查看職業目前可學的技能與後續解鎖等級。", slash="WHATSTRAINING", action="查看技能清單", icon="INV_Misc_Book_09"},
    ForeverLootSparkles = {area="quests", label="任務戰利品閃光", display="Forever Loot Sparkles", notes="讓可互動的任務物品更容易看見。", categories={"Forever Loot Sparkles", "永恆戰利品閃光"}, icon="Spell_Arcane_Arcane01"},
    Leatrix_Maps = {area="map", label="世界地圖設定", display="Leatrix Maps", notes="調整世界地圖外觀、顯示座標及探索提示。", slash="Leatrix_Maps", icon="INV_Misc_Map_01"},
    GatherMate2 = {area="map", label="採集地點紀錄", notes="在地圖上記錄草藥、礦點與魚群。", categories={"GatherMate 2", "GatherMate2"}, icon="INV_Misc_Herb_07"},
    RareScanner = {area="map", label="稀有怪與寶箱提醒", notes="遇到附近的稀有怪、寶箱或事件時顯示提示。", categories={"RareScanner", "RareScanner General"}, icon="INV_Misc_TreasureChest_02"},
    Lueur = {area="map", label="任務與採集發光", notes="為礦草、任務物品和寶箱提供發光提示。", slash="LUEUR", icon="Spell_Holy_FlashHeal"},
    ShortestPathForever = {area="map", label="路線與導航", display="Shortest Path Forever", notes="規劃路線並指引目的地。需要 ForeverCore 才能運作。", slash="SHORTESTPATHFOREVER", icon="INV_Misc_Map_01"},
    ForeverCore = {area="map", label="永恆共用元件", notes="為最短路線等插件提供共用功能。", data=true, icon="INV_Misc_Gear_01"},
    ZoneInfoForever = {area="map", label="永恆地區資訊", display="Zone Info Forever", notes="顯示地區等級、釣魚要求等資訊。", slash="ZONEINFOFOREVER", icon="INV_Misc_Map_01"},
    AtlasLootClassic = {area="battle", label="副本掉落與裝備", display="AtlasLoot", notes="查看首領掉落、裝備推薦及各類收藏。勾選會同時管理掉落資料和設定等附屬模組。", slash="ATLASLOOT", action="查看副本掉落", settings="options", settingsModule="AtlasLootClassic_Options", icon="INV_Misc_TreasureChest_02"},
    ["DBM-Core"] = {area="battle", label="首領戰鬥警報", display="DBM", notes="提供首領技能提示、倒數計時與警告。", slash="DEADLYBOSSMODS", icon="Ability_Warrior_BattleShout"},
    ["DBM-Party-Forever"] = {area="battle", label="五人副本警報", display="DBM · 五人副本", notes="提供五人副本的首領戰警報。可在 DBM 設定中調整。", route="DBM-Core", action="DBM 設定", icon="INV_Misc_Horn_01"},
    ["DBM-Raids-Vanilla"] = {area="battle", label="團隊與世界首領警報", display="DBM · 團隊與世界首領", notes="提供團隊副本與世界首領的技能警報。可在 DBM 設定中調整。", route="DBM-Core", action="DBM 設定", icon="INV_Misc_Head_Dragon_01"},
    Platynator = {area="battle", label="怪物名條", notes="調整怪物名條、施法條及仇恨配色。", slash="Platynator", icon="Ability_Hunter_BeastCall"},
    BetterBlizzFrames = {area="battle", label="人物頭像與血條", notes="調整人物及隊伍頭像、血條、文字與狀態顯示。", slash="BBF", icon="INV_Misc_GroupLooking"},
    ThreatClassic2 = {area="battle", label="仇恨值監控", notes="顯示隊伍仇恨排行並提供警告。", slash="TC2_SLASHCMD", icon="Ability_Warrior_Taunt"},
    Baganator = {area="bags", label="背包整理", notes="分類、搜尋與排序背包物品。會一併啟用物品追蹤資料庫。", slash="Baganator", icon="INV_Misc_Bag_07"},
    Syndicator = {area="bags", label="物品追蹤資料庫", notes="追蹤各角色的物品與提示，供 Baganator 使用。", slash="Syndicator", icon="INV_Misc_Book_11"},
    Auctionator = {area="bags", label="拍賣助手", notes="搜尋拍賣商品、查詢價格及管理購物清單。", categories={"Auctionator"}, icon="INV_Misc_Coin_01"},
    QuickChannels = {area="chat", label="聊天頻道快捷列", notes="點按鈕切換發話頻道。對快捷列上的頻道按鈕按右鍵，可開啟作者的設定選單。", slash="QUICKCHANNELS", action="操作說明", icon="INV_Misc_Note_05"},
    Leatrix_Plus = {area="chat", label="便利功能", display="Leatrix Plus", notes="集中設定自動修裝、售出灰色物品和介面便利功能。", slash="Leatrix_Plus", icon="INV_Misc_Wrench_01"},
    MinimapButtonDrawer = {area="chat", label="小地圖按鈕收納", display="Minimap Button Drawer", notes="集中收納小地圖周圍的插件按鈕，方便排列與尋找。", slash="MINIMAPBUTTONDRAWER", icon="INV_Misc_Bag_10"},
}

known.Leatrix_Plus.languageHint = "語言／Language → 繁體中文"
known.Leatrix_Maps.languageHint = "選項 → 語言／Language → 繁體中文"
known.Questie.languageHint = "進階 → 介面語言 → 自動或繁體中文"
known.BetterBlizzFrames.languageHint = "繁中客戶端可取消「Force English GUI」。"
known.Lueur.languageHint = "可輸入 /lueur language zhTW 切換繁中。"

local bundles = {
    AtlasLootClassic = {"AtlasBIStooltips", "AtlasLootClassic_Collections", "AtlasLootClassic_Crafting",
        "AtlasLootClassic_Data", "AtlasLootClassic_DungeonsAndRaids", "AtlasLootClassic_Factions",
        "AtlasLootClassic_Options", "AtlasLootClassic_PvP"},
    ["DBM-Core"] = {"DBM-GUI", "DBM-StatusBarTimers", "DBM-VPVEM"},
    ["DBM-Party-Forever"] = {"DBM-Party-Vanilla"},
    ["DBM-Raids-Vanilla"] = {"DBM-Azeroth"},
}

function Hub.BundleMembers(name)
    return bundles[name]
end

function Hub.HasEmbeddedForeverCore(index)
    return C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(index, "X-Forever-Core-Embed") == "1"
end

local function clean(value)
    return (tostring(value or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

local function normalized(value)
    return clean(value):lower():gsub("[%s%p]", "")
end

local function findCategory(entry)
    if not SettingsPanel or type(SettingsPanel.GetAllCategories) ~= "function" then return end
    local ok, list = pcall(SettingsPanel.GetAllCategories, SettingsPanel)
    if not ok or type(list) ~= "table" then return end
    local wanted = { [normalized(entry.name)] = true, [normalized(entry.title)] = true }
    for _, name in ipairs(entry.adapter.categories or {}) do wanted[normalized(name)] = true end
    local seen = {}
    local function search(items)
        for _, cat in pairs(items) do
            if type(cat) == "table" and not seen[cat] then
                seen[cat] = true
                if type(cat.GetName) == "function" and type(cat.GetID) == "function" then
                    local nameOK, name = pcall(cat.GetName, cat)
                    if nameOK and wanted[normalized(name)] then
                        local idOK, id = pcall(cat.GetID, cat)
                        if idOK and id ~= nil then return id end
                    end
                end
                if type(cat.GetSubcategories) == "function" then
                    local childrenOK, children = pcall(cat.GetSubcategories, cat)
                    if childrenOK and type(children) == "table" then
                        local id = search(children)
                        if id ~= nil then return id end
                    end
                end
            end
        end
    end
    return search(list)
end

function Hub.Collect()
    local result, installed, grouped = {}, {}, {}
    if not C_AddOns or not C_AddOns.GetNumAddOns or not C_AddOns.GetAddOnInfo then return result end
    for index = 1, C_AddOns.GetNumAddOns() do
        local name, title, notes = C_AddOns.GetAddOnInfo(index)
        if type(name) == "string" and name:lower() ~= ADDON:lower() and not name:lower():match("^blizzard_") then
            local adapter = known[name] or {}
            local icon = C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(index, "IconTexture")
            local titleText = clean(title or name)
            installed[name] = {
                name=name, title=titleText, label=adapter.label or titleText, display=adapter.display or name,
                notes=adapter.notes or clean(notes), adapter=adapter, area=adapter.area or "chat", members={name},
                icon=tonumber(icon) or icon or ("Interface\\Icons\\" .. (adapter.icon or "INV_Misc_Gear_01")),
            }
            if name == "ShortestPathForever" and Hub.HasEmbeddedForeverCore(index) then
                installed[name].notes = "規劃路線並指引目的地。新版已內附 ForeverCore。"
            end
        end
    end
    for anchor, members in pairs(bundles) do
        if installed[anchor] then
            for _, member in ipairs(members) do
                if installed[member] then
                    grouped[member] = true
                    table.insert(installed[anchor].members, member)
                end
            end
        end
    end
    for name, entry in pairs(installed) do
        if not grouped[name] then result[#result + 1] = entry end
    end
    table.sort(result, function(a, b)
        if (known[a.name] ~= nil) ~= (known[b.name] ~= nil) then return known[a.name] ~= nil end
        if a.label ~= b.label then return a.label < b.label end
        return a.name < b.name
    end)
    return result
end

function Hub.Filter(entries, area, query)
    local found = {}
    query = tostring(query or ""):lower():match("^%s*(.-)%s*$")
    for _, entry in ipairs(entries) do
        local text = table.concat({entry.label, entry.display, entry.title, entry.notes, table.concat(entry.members, " ")}, " "):lower()
        if (not area or area == entry.area) and (query == "" or text:find(query, 1, true)) then
            found[#found + 1] = entry
        end
    end
    return found
end

function Hub.Resolve(entry, settings)
    local adapter = entry.adapter
    if adapter.data then return nil end
    local enabled, partial = Hub.EntryState(entry)
    if enabled == false and not partial then return nil, "勾選啟用並重新載入後，即可使用此插件的功能。" end
    local route = adapter.route or entry.name
    if not C_AddOns.IsAddOnLoaded(route) then
        if C_AddOns.IsAddOnLoadOnDemand and C_AddOns.IsAddOnLoadOnDemand(route) then
            return nil, "遊戲會在需要時載入這個插件。"
        end
        return nil, "插件尚未載入。請重新載入，或到遊戲插件清單查看原因。"
    end
    if settings and adapter.settingsModule then
        if C_AddOns.DoesAddOnExist and not C_AddOns.DoesAddOnExist(adapter.settingsModule) then
            return nil, "找不到 AtlasLoot 的設定模組。"
        end
        if C_AddOns.GetAddOnEnableState and C_AddOns.GetAddOnEnableState(adapter.settingsModule, UnitGUID("player")) == 0 then
            return nil, "請先啟用 AtlasLoot 的設定模組。"
        end
    end
    local callback = adapter.open and _G[adapter.open]
    if type(callback) == "function" then return callback end
    local key = adapter.slash or (known[route] and known[route].slash)
    if key and SlashCmdList and type(SlashCmdList[key]) == "function" then
        return function() SlashCmdList[key](settings and adapter.settings or "") end
    end
    local id = findCategory(entry)
    if id ~= nil and Settings and type(Settings.OpenToCategory) == "function" then
        return function() Settings.OpenToCategory(id) end
    end
    return nil, "這個插件目前沒有可從這裡開啟的設定。"
end

function Hub.Open(entry, settings)
    if InCombatLockdown() then return false, "戰鬥結束後再開啟插件設定。" end
    local launch, reason = Hub.Resolve(entry, settings)
    if not launch then return false, reason end
    local ok, err = pcall(launch)
    if not ok then
        if geterrorhandler then geterrorhandler()(err) end
        return false, "插件開啟時發生錯誤，請查看遊戲錯誤訊息。"
    end
    return true
end

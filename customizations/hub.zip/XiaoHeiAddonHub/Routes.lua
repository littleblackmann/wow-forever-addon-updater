local _, Hub = ...

-- Read-only launch adapters: no plugin enable/disable, profile or CVar changes.
local known = {
    Platynator = { label = "怪物血條與施法條", detail = "Platynator · 頭頂名條、施法顯示與仇恨配色", slash = "Platynator" },
    RareScanner = { label = "稀有怪與寶箱提醒", detail = "RareScanner · 稀有怪、寶箱與事件提示設定", categories = { "RareScanner", "RareScanner General" } },
    GatherMate2 = { label = "採集地點紀錄", detail = "GatherMate2 · 草藥、礦點與魚群的地圖紀錄", categories = { "GatherMate 2", "GatherMate2" } },
    Baganator = { label = "背包整理", detail = "Baganator · 背包分類、搜尋與排序", slash = "Baganator" },
    Syndicator = { label = "物品追蹤資料庫", detail = "Syndicator · Baganator必要元件，物品追蹤與提示設定", slash = "Syndicator" },
    Auctionator = { label = "拍賣助手", detail = "Auctionator · 拍賣搜尋、購物清單與價格設定", categories = { "Auctionator" } },
    Leatrix_Plus = { label = "便利功能百寶箱", detail = "Leatrix Plus · 修裝、售出灰色物品與日常便利設定", slash = "Leatrix_Plus" },
    QuickChannels = { label = "聊天頻道快捷列", detail = "QuickChannels · 點頻道切換發話；右鍵按鈕設定", slash = "QUICKCHANNELS", action = "操作說明" },
    BetterBlizzFrames = { label = "人物頭像與血條", detail = "BetterBlizzFrames · 外框、字體與狀態列", slash = "BBF" },
    Leatrix_Maps = { label = "世界地圖設定", detail = "Leatrix Maps · 地圖外觀與探索", slash = "Leatrix_Maps" },
    ShortestPathForever = { label = "路線與導航設定", detail = "Shortest Path Forever · 導航與路線", slash = "SHORTESTPATHFOREVER" },
    ZoneInfoForever = { label = "地區資訊設定", detail = "Zone Info · 地區等級與資訊顯示", slash = "ZONEINFOFOREVER" },
    ForeverLootSparkles = { label = "任務戰利品閃光", detail = "Forever Loot Sparkles · 任務物品的原生閃光", categories = { "Forever Loot Sparkles", "永恆戰利品閃光" } },
    MinimapButtonDrawer = { label = "小地圖按鈕收納", detail = "Minimap Button Drawer · 按鈕排列與收納", slash = "MINIMAPBUTTONDRAWER" },
    AtlasLootClassic = { label = "副本掉落與裝備", detail = "AtlasLoot · 副本掉落與裝備推薦", slash = "ATLASLOOT", action = "查看" },
    ThreatClassic2 = { label = "仇恨值監控", detail = "ThreatClassic2 · 仇恨列表與警報設定", slash = "TC2_SLASHCMD" },
    Questie = { label = "任務助手", detail = "Questie · 任務位置、地圖標記與追蹤設定", slash = "ACECONSOLE_QUESTIE" },
    QuestieDB = { label = "路線地點資料庫", detail = "QuestieDB · 供最短路線查詢附近服務，無獨立設定視窗" },
    ["DBM-Core"] = { label = "首領戰鬥警報", detail = "DBM · 首領技能提示與計時", slash = "DEADLYBOSSMODS" },
    Lueur = { label = "任務與採集發光", detail = "Lueur · 礦草、任務物品與寶箱提示", slash = "LUEUR" },
    WhatsTraining = { label = "技能學習清單", detail = "What's Training · 查看可學的技能", slash = "WHATSTRAINING", action = "查看" },
}

local function clean(value)
    return tostring(value or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
end

local function normalized(value)
    return clean(value):lower():gsub("[%s%p]", "")
end

local function categories()
    if SettingsPanel and type(SettingsPanel.GetAllCategories) == "function" then
        local ok, list = pcall(SettingsPanel.GetAllCategories, SettingsPanel)
        if ok and type(list) == "table" then return list end
    end
    return {}
end

local function findCategory(entry)
    local wanted = { [normalized(entry.name)] = true, [normalized(entry.title)] = true }
    for _, name in ipairs(entry.adapter.categories or {}) do wanted[normalized(name)] = true end
    local seen = {}
    local function search(list)
        for _, cat in pairs(list) do
            if type(cat) == "table" and not seen[cat] then
                seen[cat] = true
                if type(cat.GetName) == "function" and type(cat.GetID) == "function" then
                    local nameOK, name = pcall(cat.GetName, cat)
                    local idOK, id = pcall(cat.GetID, cat)
                    if nameOK and idOK and id ~= nil and wanted[normalized(name)] then return id end
                end
                if type(cat.GetSubcategories) == "function" then
                    local ok, children = pcall(cat.GetSubcategories, cat)
                    if ok and type(children) == "table" then
                        local id = search(children)
                        if id ~= nil then return id end
                    end
                end
            end
        end
    end
    return search(categories())
end

function Hub.Collect()
    local result = {}
    if not C_AddOns or not C_AddOns.GetNumAddOns or not C_AddOns.GetAddOnInfo then return result end
    for index = 1, C_AddOns.GetNumAddOns() do
        local name, title, notes = C_AddOns.GetAddOnInfo(index)
        if type(name) == "string" and name ~= "XiaoHeiAddonHub" and not name:match("^Blizzard_") then
            local adapter = known[name] or {}
            local loaded = C_AddOns.IsAddOnLoaded(name) and true or false
            local icon = C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(name, "IconTexture")
            result[#result + 1] = {
                name = name, title = clean(title or name), notes = clean(notes), adapter = adapter,
                label = adapter.label or clean(title or name), detail = adapter.detail or clean(notes or name),
                loaded = loaded, icon = tonumber(icon) or icon or "Interface\\Icons\\INV_Misc_Gear_01",
            }
        end
    end
    table.sort(result, function(a, b)
        if a.loaded ~= b.loaded then return a.loaded end
        if (known[a.name] ~= nil) ~= (known[b.name] ~= nil) then return known[a.name] ~= nil end
        return a.label < b.label
    end)
    return result
end

function Hub.Filter(entries, query)
    local found = {}
    query = tostring(query or ""):lower()
    for _, entry in ipairs(entries) do
        local text = table.concat({entry.label, entry.name, entry.title, entry.detail}, " "):lower()
        if query == "" or text:find(query, 1, true) then found[#found + 1] = entry end
    end
    return found
end

function Hub.Resolve(entry)
    if not C_AddOns.IsAddOnLoaded(entry.name) then return nil, "尚未載入，請先在遊戲的插件清單啟用，再重新登入。" end
    local key = entry.adapter.slash
    if key and SlashCmdList and type(SlashCmdList[key]) == "function" then
        return function() SlashCmdList[key]("") end
    end
    local id = findCategory(entry)
    if id ~= nil and Settings and type(Settings.OpenToCategory) == "function" then
        return function() Settings.OpenToCategory(id) end
    end
    return nil, "尚未找到這個插件的設定入口。它可能沒有設定視窗，或需要另外接入。"
end

function Hub.Open(entry)
    if InCombatLockdown() then return false, "戰鬥結束後再開啟插件設定。" end
    local launch, reason = Hub.Resolve(entry)
    if not launch then return false, reason end
    local ok, err = pcall(launch)
    if not ok then
        if geterrorhandler then geterrorhandler()(err) end
        return false, "插件開啟時發生錯誤，請查看遊戲錯誤訊息。"
    end
    return true
end

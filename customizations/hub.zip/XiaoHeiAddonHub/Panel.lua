local _, Hub = ...
local window, escape, chest, motion, base, openLid, closedLid, shield
local progress, target, skipOpening = 0, 0, false
local panel, search, details, warning, status, schemeText, remember, auto
local previous, nextPage, pageText, empty, schemeDialog
local cards, tabs, entries = {}, {}, {}
local area, selected, page = "all", nil, 1
local WIDTH, HEIGHT, COLUMNS, PAGE_SIZE = 1056, 704, 4, 8
local HINGE = 316
local media = "Interface\\AddOns\\XiaoHeiAddonHub\\Media\\"
local chestArt, plaqueArt = media .. "Chest.tga", media .. "Plaque.tga"

local gold = {1, 0.82, 0.45}
local light = {0.99, 0.91, 0.74}
local muted = {0.77, 0.66, 0.52}
local edge = {0.54, 0.34, 0.16}
local ink = {0.20, 0.081, 0.038}
local fadedInk = {0.32, 0.18, 0.083}
local areas = {
    {"all", "全部"},
    {"quests", "任務與升級"},
    {"map", "地圖與採集"},
    {"battle", "戰鬥與副本"},
    {"bags", "背包與拍賣"},
    {"chat", "聊天與介面"},
}

local function text(parent, style, point, x, y, width, color, size)
    local label = parent:CreateFontString(nil, "OVERLAY", style)
    label:SetPoint(point, x, y)
    if width then label:SetWidth(width) end
    if size then
        local path = label:GetFont()
        if path then label:SetFont(path, size, "") end
    end
    local centered = point == "TOP" or point == "BOTTOM" or point == "CENTER"
    label:SetJustifyH(centered and "CENTER" or "LEFT")
    label:SetJustifyV("TOP")
    label:SetTextColor(unpack(color or light))
    if color == ink or color == fadedInk then label:SetShadowOffset(0, 0) end
    return label
end

local function box(frame, r, g, b, a)
    local solid = "Interface\\Buttons\\WHITE8X8"
    frame:SetBackdrop({bgFile=solid, edgeFile=solid, edgeSize=2})
    frame:SetBackdropColor(r or 0.12, g or 0.069, b or 0.04, a or 1)
    frame:SetBackdropBorderColor(unpack(edge))
end

local function image(parent, file, layer, x, y, width, height)
    local texture = parent:CreateTexture(nil, layer)
    texture:SetPoint("TOPLEFT", x, y)
    texture:SetSize(width, height)
    texture:SetTexture(file)
    return texture
end

local function plaqueRegion(parent, layer, x, y, w, h, left, right, top, bottom)
    local texture = image(parent, plaqueArt, layer, x, y, w, h)
    -- Sample the source artwork in separate sections so the ring stays round
    -- and the ornamental ends keep their shape in a narrower badge.
    texture:SetTexCoord(left / 2135, right / 2135, top / 737, bottom / 737)
    return texture
end

local function maskCircle(parent, texture)
    if not parent.CreateMaskTexture or not texture.AddMaskTexture then return end
    local mask = parent:CreateMaskTexture()
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(texture)
    texture:AddMaskTexture(mask)
end

local function rule(parent, x, y, width)
    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetPoint("TOPLEFT", x, y)
    line:SetSize(width, 1)
    line:SetColorTexture(edge[1], edge[2], edge[3], 1)
end

local function action(parent, label, width, height, callback, primary)
    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width, height)
    box(button)
    if primary then
        button:SetBackdropColor(0.32, 0.068, 0.042, 1)
        button:SetBackdropBorderColor(0.76, 0.47, 0.23, 1)
    end
    local surface = image(button, chestArt, "BORDER", 2, -2, width - 4, height - 4)
    if primary then surface:SetTexCoord(0.24, 0.46, 0.56, 0.61)
    else surface:SetTexCoord(0.28, 0.51, 0.38, 0.43) end
    surface:SetAlpha(0.56)
    button.surface = surface
    local title = text(button, "GameFontNormal", "CENTER", 0, 0, width - 8, primary and gold or light, 15)
    title:SetJustifyH("CENTER")
    title:SetText(label)
    button.label = title
    local hover = button:CreateTexture(nil, "HIGHLIGHT")
    hover:SetAllPoints()
    hover:SetColorTexture(0.85, 0.68, 0.34, 0.13)
    button:SetScript("OnClick", callback)
    button:SetScript("OnEnable", function(self) self:SetAlpha(1) end)
    button:SetScript("OnDisable", function(self) self:SetAlpha(0.45) end)
    return button
end

local function check(parent, callback)
    local button = CreateFrame("CheckButton", nil, parent, "BackdropTemplate")
    button:SetSize(22, 22)
    box(button, 0.115, 0.063, 0.033, 1)
    button:SetBackdropBorderColor(0.77, 0.53, 0.24, 1)
    button:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    button:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
    button:SetScript("OnClick", function(self) callback(self:GetChecked() and true or false) end)
    button:SetScript("OnEnable", function(self) self:SetAlpha(1) end)
    button:SetScript("OnDisable", function(self) self:SetAlpha(0.5) end)
    return button
end

local function icon(parent, size, x, y)
    local image = parent:CreateTexture(nil, "ARTWORK", nil, 2)
    image:SetPoint("TOPLEFT", x, y)
    image:SetSize(size, size)
    image:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    return image
end

local function smooth(value)
    local t = math.max(0, math.min(1, value))
    return t * t * (3 - 2 * t)
end

local function drawChest(p)
    local unfolding = p < 0.60
    motion:SetShown(unfolding)
    chest:SetShown(not unfolding)
    panel:SetAlpha(smooth((p - 0.60) / 0.17))
    for index, card in ipairs(cards) do
        card:SetAlpha(smooth((p - 0.60 - (index - 1) * 0.027) / 0.19))
    end
    if not unfolding then return end

    local swing = smooth((p - 0.14) / 0.46)
    local face = math.cos(math.pi * swing)
    local hingeY = -HINGE + 104 * (1 - swing)
    motion:SetAlpha(smooth(p / 0.14))
    base:SetPoint("TOPLEFT", motion, "TOPLEFT", 0, hingeY)
    -- The wood exterior foreshortens onto the hinge, then the parchment
    -- interior grows upward. Both are anchored on the same edge of the base.
    closedLid:SetShown(face >= 0)
    openLid:SetShown(face < 0)
    if face >= 0 then
        closedLid:SetPoint("TOP", motion, "TOP", 0, hingeY - 1)
        closedLid:SetHeight(math.max(1, 256 * face))
    else
        openLid:SetPoint("BOTTOMLEFT", motion, "TOPLEFT", 0, hingeY)
        openLid:SetHeight(math.max(1, -HINGE * face))
    end
end

local function finishMotion()
    window:SetScript("OnUpdate", nil)
    shield:Hide()
    if target == 0 then window:Hide() end
end

local function tick(_, elapsed)
    if target == 1 then
        progress = math.min(1, progress + elapsed / 1.02)
    else
        progress = math.max(0, progress - elapsed / 0.96)
    end
    drawChest(progress)
    if progress == target then finishMotion() end
end

local function playChest(direction)
    target = direction
    if target == 0 then
        search:ClearFocus()
        if schemeDialog then schemeDialog:Hide() end
        GameTooltip:Hide()
    end
    if progress == target then
        finishMotion()
    else
        shield:Show()
        window:SetScript("OnUpdate", tick)
    end
end

local function showResult(ok, message, changed, single)
    if not ok then
        warning:SetText(message or "遊戲未接受這次變更。")
    elseif changed and #changed > (single and 1 or 0) then
        warning:SetText(single and ("已調整 %d 個插件與相依元件。"):format(#changed)
            or ("已套用插件方案，共變更 %d 個項目。"):format(#changed))
    else
        warning:SetText(single and "" or "目前角色已符合共用方案。")
    end
end

local function refreshDetails(entry)
    details.content:SetShown(entry ~= nil)
    if not entry then return end
    local enabled, partial = Hub.EntryState(entry)
    details.icon:SetTexture(entry.icon)
    details.name:SetText(entry.label)
    details.original:SetText(entry.display)
    details.notes:SetText(entry.notes ~= "" and entry.notes or "作者尚未提供這個插件的說明。")
    details.status:SetText(partial and "部分元件已啟用" or (enabled == nil and "無法讀取啟用狀態"
        or (enabled and "已啟用" or "已停用")))
    details.status:SetTextColor(unpack((enabled or partial) and ink or fadedInk))
    local launch, reason = Hub.Resolve(entry)
    local settings, settingsReason
    if entry.adapter.settings then settings, settingsReason = Hub.Resolve(entry, true) end
    details.launch.label:SetText(entry.adapter.action or "插件設定")
    details.launch:SetShown(launch ~= nil or entry.adapter.settings ~= nil)
    details.launch:SetEnabled(launch ~= nil)
    details.settings:SetShown(entry.adapter.settings ~= nil)
    details.settings:SetEnabled(settings ~= nil)
    details.reason:SetText(reason or settingsReason or entry.adapter.languageHint or "")
end

local function refresh()
    local list = Hub.Filter(entries, area ~= "all" and area or nil, search:GetText())
    local count = math.max(1, math.ceil(#list / PAGE_SIZE))
    page = math.max(1, math.min(page, count))
    local first = (page - 1) * PAGE_SIZE + 1
    local active
    for i, card in ipairs(cards) do
        local entry = list[first + i - 1]
        card.entry = entry
        if entry and entry.name == selected then active = entry end
    end
    active = active or list[first]
    selected = active and active.name
    for _, card in ipairs(cards) do
        local entry = card.entry
        card:SetShown(entry ~= nil)
        if entry then
            local enabled, partial = Hub.EntryState(entry)
            card.check:SetEnabled(enabled ~= nil and Hub.CanChange() and true or false)
            card.check:SetChecked(enabled or partial or false)
            card.check:GetCheckedTexture():SetVertexColor(partial and 0.58 or 1, partial and 0.58 or 1, partial and 0.58 or 1)
            card.icon:SetTexture(entry.icon)
            card.icon:SetDesaturated(enabled == false and not partial)
            card.title:SetText(entry.label)
            card.original:SetText(entry.display)
            local current = entry == active
            for _, section in ipairs(card.plaque) do
                section:SetVertexColor(1, current and 0.98 or 0.88, current and 0.94 or 0.75)
            end
            card.selection:SetShown(current)
        end
    end
    for key, tab in pairs(tabs) do
        local current = key == area
        tab.label:SetTextColor(unpack(current and ink or light))
        tab:SetBackdropColor(current and 0.76 or 0.19, current and 0.50 or 0.095, current and 0.22 or 0.050, 1)
        tab:SetBackdropBorderColor(unpack(current and gold or edge))
        tab.surface:SetAlpha(current and 0.13 or 0.50)
    end
    refreshDetails(active)
    local owner, remembering, automatic, canApply = Hub.ProfileInfo()
    schemeText:SetText(owner and ("共用方案 · " .. owner) or "尚未儲存共用方案")
    remember:SetChecked(remembering or false)
    remember:SetEnabled(Hub.CanChange() and true or false)
    auto:SetChecked(automatic or false)
    auto:SetEnabled(canApply and Hub.CanChange() and true or false)
    if schemeDialog and schemeDialog:IsShown() then schemeDialog.apply:SetEnabled(canApply and true or false) end
    status:SetText(Hub.HasChanges() and "變更將在重新載入後生效" or "")
    empty:SetShown(#list == 0)
    previous:SetEnabled(page > 1)
    nextPage:SetEnabled(page < count)
    pageText:SetText(("%d / %d"):format(page, count))
end

local function selectPage(value)
    page = value
    refresh()
end

local function pageButton(parent, offset, step, hint)
    local button = action(parent, "", 31, 27, function() selectPage(page + step) end)
    button:SetPoint("TOP", offset, -650)
    -- The game font can display missing glyph boxes for Unicode chevrons.
    local tip = step * 3.5
    for _, y in ipairs({5.5, -5.5}) do
        local stroke = button:CreateLine(nil, "ARTWORK")
        stroke:SetThickness(2.2)
        stroke:SetColorTexture(gold[1], gold[2], gold[3], 1)
        stroke:SetStartPoint("CENTER", button, -tip, y)
        stroke:SetEndPoint("CENTER", button, tip, 0)
    end
    button:SetScript("OnEnter", function(self) Hub.Tooltip(self, hint, {}) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return button
end

local function launch(settings)
    for _, entry in ipairs(entries) do
        if entry.name == selected then
            if not Hub.Resolve(entry, settings) then return end
            window:Hide()
            local ok, message = Hub.Open(entry, settings)
            if not ok then
                skipOpening = true
                window:Show()
                warning:SetText(message)
            end
            return
        end
    end
end

local function showScheme()
    if not schemeDialog then
        local cover = CreateFrame("Frame", nil, panel, "BackdropTemplate")
        cover:SetAllPoints()
        cover:SetFrameLevel(panel:GetFrameLevel() + 16)
        cover:EnableMouse(true)
        box(cover, 0.025, 0.022, 0.019, 0.83)
        local frame = CreateFrame("Frame", nil, cover, "BackdropTemplate")
        frame:SetSize(488, 245)
        frame:SetPoint("CENTER")
        box(frame, 0.105, 0.093, 0.072, 1)
        text(frame, "GameFontNormalLarge", "TOPLEFT", 24, -22, 430, gold):SetText("插件方案")
        cover.owner = text(frame, "GameFontHighlight", "TOPLEFT", 24, -56, 440, light)
        rule(frame, 24, -83, 440)
        local help = text(frame, "GameFontHighlight", "TOPLEFT", 24, -100, 440, light)
        help:SetSpacing(6)
        help:SetText("在主角色勾選「記住目前角色」以儲存啟用狀態。在分身勾選「分身自動套用」，下次登入會套用更新過的方案。各插件內部設定由插件自行保存。")
        cover.apply = action(frame, "套用到目前角色", 155, 32, function()
            local ok, message, changed = Hub.ApplyProfile(false)
            cover:Hide()
            showResult(ok, message, changed)
            refresh()
        end, true)
        cover.apply:SetPoint("BOTTOMRIGHT", -24, 22)
        local close = action(frame, "返回", 82, 32, function() cover:Hide() end)
        close:SetPoint("RIGHT", cover.apply, "LEFT", -8, 0)
        schemeDialog = cover
    end
    local owner = Hub.ProfileInfo()
    schemeDialog.owner:SetText(owner and ("方案來源 · " .. owner) or "尚未儲存共用方案")
    search:ClearFocus()
    schemeDialog:Show()
    refresh()
end

local function createPanel()
    window = CreateFrame("Frame", "XiaoHeiAddonHubWindow", UIParent)
    window:Hide()
    window:SetSize(WIDTH, HEIGHT)
    window:SetPoint("CENTER")
    window:SetFrameStrata("DIALOG")
    window:SetClampedToScreen(true)
    window:SetMovable(true)
    window:EnableMouse(true)
    chest = image(window, chestArt, "BACKGROUND", 0, 0, WIDTH, HEIGHT)
    motion = CreateFrame("Frame", nil, window)
    motion:SetAllPoints()
    base = image(motion, chestArt, "BACKGROUND", 0, -HINGE, WIDTH, HEIGHT - HINGE)
    base:SetTexCoord(0, 1, HINGE / HEIGHT, 1)
    openLid = image(motion, chestArt, "ARTWORK", 0, 0, WIDTH, HINGE)
    openLid:ClearAllPoints()
    openLid:SetTexCoord(0, 1, 0, HINGE / HEIGHT)
    closedLid = image(motion, media .. "Lid.tga", "ARTWORK", 22, -HINGE, WIDTH - 44, 256)
    closedLid:ClearAllPoints()
    closedLid:SetTexCoord(0.004, 0.996, 0.26, 0.744)
    panel = CreateFrame("Frame", nil, window)
    panel:SetAllPoints()
    shield = CreateFrame("Frame", nil, window)
    shield:SetAllPoints()
    shield:SetFrameLevel(window:GetFrameLevel() + 40)
    shield:EnableMouse(true)
    shield:EnableMouseWheel(true)
    shield:SetScript("OnMouseWheel", function() end)
    shield:Hide()
    -- Let the native Escape handler hide an invisible child while the
    -- actual window stays visible long enough to animate the lid closing.
    escape = CreateFrame("Frame", "XiaoHeiAddonHubEscape", window)
    escape:Hide()
    UISpecialFrames[#UISpecialFrames + 1] = escape:GetName()
    escape:SetScript("OnHide", function(self)
        if not window:IsVisible() or self:IsShown() then return end
        playChest(0)
        if window:IsShown() then self:Show() end
    end)
    local header = CreateFrame("Frame", nil, panel)
    header:SetPoint("TOPLEFT", 36, -8)
    header:SetSize(WIDTH - 72, 48)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() window:StartMoving() end)
    header:SetScript("OnDragStop", function() window:StopMovingOrSizing() end)
    text(header, "GameFontNormalLarge", "TOP", 0, -9, 315, ink, 27):SetText("小黑插件總入口")
    local close = action(header, "×", 34, 30, function() playChest(0) end, true)
    close:SetPoint("TOPRIGHT", -23, -7)

    remember = check(panel, function(value)
        local ok, message = Hub.Remember(value)
        warning:SetText(ok and "" or message)
        refresh()
    end)
    remember:SetPoint("TOPLEFT", 207, -264)
    text(panel, "GameFontHighlight", "TOPLEFT", 237, -268, 120, light, 14):SetText("記住目前角色")
    auto = check(panel, function(value)
        local ok, message = Hub.SetAuto(value)
        warning:SetText(not ok and message or (value and "下次登入時將套用主角色的插件方案。" or ""))
        refresh()
    end)
    auto:SetPoint("TOPLEFT", 372, -264)
    text(panel, "GameFontHighlight", "TOPLEFT", 402, -268, 130, light, 14):SetText("分身自動套用")
    schemeText = text(panel, "GameFontHighlightSmall", "TOPLEFT", 237, -290, 300, muted, 12)
    schemeText:SetWordWrap(false)
    local reload = action(panel, "重新載入", 118, 31, function()
        local ok, message = Hub.Reload()
        if not ok then warning:SetText(message) end
    end, true)
    reload:SetPoint("TOPRIGHT", -205, -272)
    local profile = action(panel, "插件方案", 118, 31, showScheme)
    profile:SetPoint("RIGHT", reload, "LEFT", -10, 0)

    for index, def in ipairs(areas) do
        local key, name = unpack(def)
        local tab = action(panel, name, 146, 43, function()
            area, page, selected = key, 1, nil
            warning:SetText("")
            refresh()
        end)
        tab:SetPoint("TOPLEFT", 65 + (index - 1) * 156, -585)
        tabs[key] = tab
    end
    local gameList = action(panel, "遊戲插件清單", 129, 28, function()
        if InCombatLockdown() then return end
        if not AddonList and C_AddOns and C_AddOns.LoadAddOn then pcall(C_AddOns.LoadAddOn, "Blizzard_AddOnList") end
        if AddonList then
            window:Hide()
            ShowUIPanel(AddonList)
        else
            warning:SetText("按 Esc → 插件，可開啟遊戲的插件清單。")
        end
    end)
    gameList:SetPoint("TOPLEFT", 66, -649)

    search = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    search:SetSize(384, 27)
    search:SetPoint("TOP", 0, -325)
    search:SetAutoFocus(false)
    search:SetMaxLetters(80)
    local placeholder = text(search, "GameFontHighlight", "LEFT", 6, 0, 250, muted, 14)
    placeholder:SetText("搜尋插件")
    search:SetScript("OnTextChanged", function(self)
        placeholder:SetShown(self:GetText() == "")
        selectPage(1)
    end)
    search:SetScript("OnEscapePressed", function() playChest(0) end)
    search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    local grid = CreateFrame("Frame", nil, panel)
    grid:SetPoint("TOPLEFT", 46, -372)
    grid:SetSize(964, 189)
    grid:EnableMouseWheel(true)
    grid:SetScript("OnMouseWheel", function(_, delta) selectPage(page - delta) end)
    empty = text(grid, "GameFontHighlight", "TOP", 0, -106, 400, muted)
    empty:SetText("找不到符合的插件。")

    for index = 1, PAGE_SIZE do
        local column, row = (index - 1) % COLUMNS, math.floor((index - 1) / COLUMNS)
        local card = CreateFrame("Button", nil, grid)
        card:SetSize(230, 84)
        card:SetPoint("TOPLEFT", 6 + 241 * column, -3 - 94 * row)
        card.plaque = {
            plaqueRegion(card, "BACKGROUND", 0, 0, 87, 84, 36, 405, 188, 546),
            plaqueRegion(card, "BACKGROUND", 87, 0, 121, 84, 405, 2006, 188, 546),
            plaqueRegion(card, "BACKGROUND", 208, 0, 22, 84, 2006, 2101, 188, 546),
        }
        card.icon = icon(card, 56, 20, -14)
        maskCircle(card, card.icon)
        card.title = text(card, "GameFontNormal", "TOPLEFT", 88, -25, 114, ink, 14)
        card.title:SetWordWrap(false)
        card.original = text(card, "GameFontHighlightSmall", "TOPLEFT", 88, -49, 128, fadedInk, 12)
        card.original:SetWordWrap(false)
        card.selection = card:CreateTexture(nil, "ARTWORK")
        card.selection:SetPoint("BOTTOMLEFT", 14, 2)
        card.selection:SetSize(202, 3)
        card.selection:SetColorTexture(gold[1], gold[2], gold[3], 1)
        local hover = card:CreateTexture(nil, "HIGHLIGHT")
        hover:SetPoint("TOPLEFT", 9, -8)
        hover:SetSize(212, 68)
        hover:SetColorTexture(1, 0.85, 0.48, 0.13)
        card:EnableMouseWheel(true)
        card:SetScript("OnMouseWheel", function(_, delta) selectPage(page - delta) end)
        card:SetScript("OnClick", function(self)
            if self.entry then selected = self.entry.name refresh() end
        end)
        card:SetScript("OnEnter", function(self)
            if self.entry then Hub.Tooltip(self, self.entry.label, {self.entry.display}) end
        end)
        card:SetScript("OnLeave", function() GameTooltip:Hide() end)
        card.check = check(card, function(value)
            if not card.entry then return end
            selected = card.entry.name
            local ok, message, changed = Hub.Turn(card.entry, value)
            showResult(ok, message, changed, true)
            refresh()
        end)
        card.check:SetPoint("TOPRIGHT", -11, -10)
        card.check:SetScript("OnEnter", function(self)
            Hub.Tooltip(self, "目前角色", {"勾選啟用，取消勾選停用。", "改好後按「重新載入」。"})
        end)
        card.check:SetScript("OnLeave", function() GameTooltip:Hide() end)
        cards[index] = card
    end
    previous = pageButton(panel, -55, -1, "上一頁")
    nextPage = pageButton(panel, 55, 1, "下一頁")
    pageText = text(panel, "GameFontHighlight", "TOP", 0, -657, 72, light, 14)

    local content = CreateFrame("Frame", nil, panel)
    content:SetAllPoints()
    details = {content=content}
    local crest = plaqueRegion(content, "ARTWORK", 90, -88, 134, 134, 89, 390, 216, 517)
    maskCircle(content, crest)
    details.icon = icon(content, 100, 107, -105)
    maskCircle(content, details.icon)
    details.name = text(content, "GameFontNormalLarge", "TOPLEFT", 248, -93, 418, ink, 26)
    details.name:SetWordWrap(false)
    details.original = text(content, "GameFontHighlight", "TOPLEFT", 249, -130, 300, fadedInk, 16)
    details.original:SetWordWrap(false)
    details.status = text(content, "GameFontHighlightSmall", "TOPLEFT", 542, -134, 120, fadedInk, 13)
    details.status:SetJustifyH("RIGHT")
    rule(content, 248, -154, 416)
    details.notes = text(content, "GameFontHighlight", "TOPLEFT", 249, -168, 415, ink, 16)
    details.notes:SetMaxLines(3)
    details.notes:SetSpacing(4)
    details.launch = action(content, "", 214, 35, function() launch(false) end, true)
    details.launch:SetPoint("TOPLEFT", 703, -107)
    details.settings = action(content, "插件設定", 214, 35, function() launch(true) end)
    details.settings:SetPoint("TOPLEFT", 703, -151)
    details.reason = text(content, "GameFontHighlight", "TOPLEFT", 703, -194, 214, fadedInk, 13)
    details.reason:SetMaxLines(2)

    warning = text(panel, "GameFontHighlightSmall", "TOP", 0, -683, 880, light, 12)
    status = text(panel, "GameFontHighlightSmall", "TOPRIGHT", -66, -657, 292, gold, 13)
    status:SetJustifyH("RIGHT")
    window:SetScript("OnShow", function()
        local scale = math.min(1, math.max(0.1, (UIParent:GetHeight() - 32) / HEIGHT),
            math.max(0.1, (UIParent:GetWidth() - 24) / WIDTH))
        window:SetScale(scale)
        Hub.Scan()
        entries = Hub.Collect()
        refresh()
        escape:Show()
        if skipOpening then
            skipOpening = false
            progress, target = 1, 1
            drawChest(1)
        else
            drawChest(0)
            playChest(1)
        end
    end)
    window:SetScript("OnHide", function()
        window:SetScript("OnUpdate", nil)
        progress, target = 0, 0
        shield:Hide()
        escape:Hide()
        window:StopMovingOrSizing()
        if schemeDialog then schemeDialog:Hide() end
        search:ClearFocus()
        GameTooltip:Hide()
    end)
end

function Hub.Toggle()
    if InCombatLockdown() then Hub.Say("戰鬥結束後再開啟插件選單。") return end
    if not window then createPanel() end
    if window:IsShown() then playChest(1 - target)
    else window:Show() end
end

function Hub.ClosePanel()
    if window then window:Hide() end
end

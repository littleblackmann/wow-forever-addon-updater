-- Minimap Button Drawer - config window
-- Right-click the drawer button (or type /mbd) to open it.

local ADDON, ns = ...
local MBD = ns.MBD

--------------------------------------------------------------------------
-- Style
--------------------------------------------------------------------------

-- Two looks for the config window:
--   modern  - flat neutral greys with a single blue accent
--   classic - Blizzard's own frames: dialog border, gold headings, red buttons
local THEMES = {
    modern = {
        bg       = { 0.085, 0.087, 0.095, 0.97 },
        header   = { 0.115, 0.118, 0.130, 1 },
        field    = { 0.055, 0.057, 0.063, 1 },   -- inputs, list background
        button   = { 0.150, 0.153, 0.168, 1 },
        buttonHi = { 0.190, 0.194, 0.212, 1 },
        border   = { 0.205, 0.210, 0.230, 1 },
        accent   = { 0.290, 0.560, 0.890, 1 },
        text     = { 0.900, 0.905, 0.920, 1 },
        muted    = { 0.550, 0.560, 0.600, 1 },
        line     = { 0.205, 0.210, 0.230, 1 },
        title    = { 0.550, 0.560, 0.600, 1 },
        hex      = "e6e7eb",
    },
    classic = {
        bg       = { 1, 1, 1, 1 },
        header   = { 0, 0, 0, 0.45 },
        field    = { 0, 0, 0, 0.6 },
        button   = { 0.16, 0.13, 0.08, 0.9 },
        buttonHi = { 0.26, 0.20, 0.10, 0.9 },
        border   = { 0.60, 0.60, 0.60, 1 },
        accent   = { 1, 0.82, 0, 1 },
        text     = { 1, 1, 1, 1 },
        muted    = { 0.62, 0.62, 0.62, 1 },
        line     = { 0.55, 0.45, 0.20, 0.7 },
        title    = { 1, 0.82, 0, 1 },
        hex      = "ffffff",
    },
}
local C = {}
local STYLE = "modern"
local TEXT_HEX = "e6e7eb"

local function ApplyTheme(name)
    STYLE = THEMES[name] and name or "modern"
    for k, v in pairs(THEMES[STYLE]) do C[k] = v end
    TEXT_HEX = C.hex
end
ApplyTheme("modern")

local function IsClassic() return STYLE == "classic" end

local WHITE = "Interface\\Buttons\\WHITE8x8"
local FLAT = { bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 }
local CLASSIC_BOX = {
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
}
local CLASSIC_SMALL = {
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 8,
    insets = { left = 2, right = 2, top = 2, bottom = 2 },
}
-- Fallback when the client has no BasicFrameTemplate: dialog border
-- around a solid (not see-through) fill.
local CLASSIC_WINDOW = {
    bgFile = WHITE,
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
}

local WIDTH, HEIGHT = 440, 740
local PAD = 16               -- outer padding
local COL2 = 228             -- x of the right-hand column
local COLW = WIDTH - COL2 - PAD
local ROW_HEIGHT = 26

-- x positions of the list columns, relative to a row
local X_HANDLE, X_SHOW, X_COLLECT, X_ICON = 14, 46, 98, 130

local rows = {}
local win, content, scroll, dropLine, ghost, countText
local controls = {}
local drag

local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata

-- small = the frame is a 22px-ish control (thinner classic border)
local function Flat(f, bg, border, small)
    if IsClassic() then
        if small == nil then
            local w, h = f:GetSize()
            small = (w and w > 0 and w <= 24) or (h and h > 0 and h <= 24)
        end
        f:SetBackdrop(small and CLASSIC_SMALL or CLASSIC_BOX)
    else
        f:SetBackdrop(FLAT)
    end
    f:SetBackdropColor(unpack(bg or C.field))
    f:SetBackdropBorderColor(unpack(border or C.border))
end

local function Text(parent, template, color)
    local fs = parent:CreateFontString(nil, "ARTWORK", template or "GameFontHighlight")
    fs:SetTextColor(unpack(color or C.text))
    fs:SetJustifyH("LEFT")
    return fs
end

local function Tooltip(frame, title, body)
    frame:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(title, 1, 1, 1)
        if body then GameTooltip:AddLine(body, 0.75, 0.76, 0.80, true) end
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", GameTooltip_Hide)
end

--------------------------------------------------------------------------
-- Widgets
--------------------------------------------------------------------------

-- Checkbox: an outlined square that fills with the accent colour when on.
local function MakeClassicToggle(parent, label, onChange)
    local b = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    b:SetSize(22, 22)
    if type(b.Text) == "table" and b.Text.SetText then b.Text:SetText("") end
    if label then
        local fs = Text(b)
        fs:SetPoint("LEFT", b, "RIGHT", 4, 1)
        fs:SetText(label)
        b:SetHitRectInsets(0, -(fs:GetStringWidth() + 8), 0, 0)
        b.label = fs
    end
    b:SetScript("OnClick", function(self)
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        onChange(self:GetChecked() and true or false)
    end)
    b:HookScript("OnDisable", function(self) self:SetAlpha(0.4) end)
    b:HookScript("OnEnable", function(self) self:SetAlpha(1) end)
    return b
end

local function MakeToggle(parent, label, onChange)
    if IsClassic() then return MakeClassicToggle(parent, label, onChange) end
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(16, 16)
    Flat(b, C.field, C.border)

    local fill = b:CreateTexture(nil, "ARTWORK")
    fill:SetPoint("TOPLEFT", 1, -1)
    fill:SetPoint("BOTTOMRIGHT", -1, 1)
    fill:SetColorTexture(unpack(C.accent))
    local tick = b:CreateTexture(nil, "OVERLAY")
    tick:SetSize(16, 16)
    tick:SetPoint("CENTER", 1, 0)
    tick:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    tick:SetDesaturated(true)
    tick:SetVertexColor(1, 1, 1)

    if label then
        local fs = Text(b)
        fs:SetPoint("LEFT", b, "RIGHT", 8, 0)
        fs:SetText(label)
        b:SetHitRectInsets(0, -(fs:GetStringWidth() + 10), 0, 0)
        b.label = fs
    end

    function b:SetChecked(v)
        self.checked = v and true or false
        fill:SetShown(self.checked)
        tick:SetShown(self.checked)
        self:SetBackdropBorderColor(unpack(self.checked and C.accent or C.border))
    end
    function b:GetChecked() return self.checked end

    b:SetScript("OnClick", function(self)
        self:SetChecked(not self.checked)
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        onChange(self.checked)
    end)
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(C.accent)) end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(unpack(self.checked and C.accent or C.border))
    end)
    b:SetScript("OnDisable", function(self) self:SetAlpha(0.3) end)
    b:SetScript("OnEnable", function(self) self:SetAlpha(1) end)
    b:SetChecked(false)
    return b
end

-- Flat neutral button.
local function MakeButton(parent, text, width, onClick)
    if IsClassic() then
        local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        b:SetSize(width, 22)
        b:SetText(text)
        b.text = b:GetFontString()
        b:SetScript("OnClick", function(...)
            PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION or 852)
            onClick(...)
        end)
        return b
    end
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(width, 22)
    Flat(b, C.button, C.border)
    local fs = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    fs:SetPoint("CENTER")
    fs:SetText(text)
    fs:SetTextColor(unpack(C.text))
    b.text = fs
    b:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(C.buttonHi))
        self:SetBackdropBorderColor(unpack(C.accent))
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropColor(unpack(C.button))
        self:SetBackdropBorderColor(unpack(C.border))
    end)
    b:SetScript("OnMouseDown", function() fs:SetPoint("CENTER", 0, -1) end)
    b:SetScript("OnMouseUp", function() fs:SetPoint("CENTER") end)
    b:SetScript("OnClick", function(...)
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION or 852)
        onClick(...)
    end)
    return b
end

-- "Label            [-] value [+]"  (fills one column)
local function MakeStepper(parent, label, min, max, step, get, set)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(COLW, 22)
    local fs = Text(f)
    fs:SetPoint("LEFT")
    fs:SetText(label)

    local plus = MakeButton(f, "+", 22, function() set(math.min(max, get() + step)); f:Refresh() end)
    plus:SetPoint("RIGHT")
    local valBox = CreateFrame("Frame", nil, f, "BackdropTemplate")
    valBox:SetSize(38, 22)
    valBox:SetPoint("RIGHT", plus, "LEFT", -2, 0)
    Flat(valBox, C.field, C.border)
    local val = valBox:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    val:SetPoint("CENTER")
    val:SetTextColor(unpack(C.text))
    local minus = MakeButton(f, "-", 22, function() set(math.max(min, get() - step)); f:Refresh() end)
    minus:SetPoint("RIGHT", valBox, "LEFT", -2, 0)

    function f:Refresh()
        local v = get()
        val:SetText(v)
        minus:SetAlpha(v <= min and 0.4 or 1)
        plus:SetAlpha(v >= max and 0.4 or 1)
    end
    return f
end

-- 3x3 grid around the drawer icon, plus the current value and an Auto checkbox.
local GRID = {
    { "TOPLEFT", "TOP", "TOPRIGHT" },
    { "LEFT", false, "RIGHT" },
    { "BOTTOMLEFT", "BOTTOM", "BOTTOMRIGHT" },
}
local function MakeDirectionPicker(parent)
    local CELL, GAP = 18, 3
    local GRIDW = 3 * CELL + 2 * GAP
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(COLW, GRIDW)
    local cells = {}

    for r, line in ipairs(GRID) do
        for c, dir in ipairs(line) do
            local x, y = (c - 1) * (CELL + GAP), -(r - 1) * (CELL + GAP)
            if dir then
                local b = CreateFrame("Button", nil, f, "BackdropTemplate")
                b:SetSize(CELL, CELL)
                b:SetPoint("TOPLEFT", x, y)
                Flat(b, C.field, C.border)
                b.fill = b:CreateTexture(nil, "ARTWORK")
                b.fill:SetPoint("TOPLEFT", 3, -3)
                b.fill:SetPoint("BOTTOMRIGHT", -3, 3)
                b.fill:SetColorTexture(unpack(C.accent))
                b:SetScript("OnClick", function()
                    PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
                    MBD:SetDirection(dir)
                    f:Refresh()
                end)
                b:SetScript("OnEnter", function(self)
                    self:SetBackdropBorderColor(unpack(C.accent))
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:AddLine(MBD.DIRECTIONS[dir].label, 1, 1, 1)
                    GameTooltip:Show()
                end)
                b:SetScript("OnLeave", function(self)
                    self:SetBackdropBorderColor(unpack(C.border))
                    GameTooltip:Hide()
                end)
                cells[dir] = b
            else
                local center = f:CreateTexture(nil, "ARTWORK")
                center:SetSize(CELL, CELL)
                center:SetPoint("TOPLEFT", x, y)
                center:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                MBD:RegisterIconTexture(center)
                center:SetDesaturated(true)
                center:SetAlpha(0.7)
            end
        end
    end

    local value = Text(f)
    value:SetPoint("TOPLEFT", GRIDW + 14, -2)

    local auto = MakeToggle(f, "Auto", function(v)
        -- Turning Auto off keeps whichever direction Auto was using.
        MBD:SetDirection(v and "AUTO" or MBD:GetDirection())
        f:Refresh()
    end)
    auto:SetPoint("TOPLEFT", GRIDW + 14, -26)
    Tooltip(auto, "Automatic direction",
        "Open toward the middle of the screen, based on where the drawer button sits. Choose a square to set a fixed direction instead.")

    function f:Refresh()
        local isAuto = not MBD.DIRECTIONS[MBD.db.direction]
        local active = MBD:GetDirection()
        for dir, b in pairs(cells) do
            b.fill:SetShown(dir == active)
            b.fill:SetAlpha(isAuto and 0.35 or 1) -- Auto: show its current pick, dimmed
        end
        value:SetText(MBD.DIRECTIONS[active].label)
        auto:SetChecked(isAuto)
    end
    return f
end

local function SameIcon(a, b)
    a, b = MBD:NormalizeIcon(a), MBD:NormalizeIcon(b)
    if a == nil or b == nil then return false end
    return tostring(a):lower() == tostring(b):lower()
end

local function SetDrawerIcon(v)
    MBD.db.drawerIcon = v
    MBD:ApplyDrawerStyle()
    MBD:RefreshConfig()
end

-- "Label [ (swatch) Name     v ]" - a generic drop-down list.
-- o = { label, labelWidth, listWidth, items = { {value, label}... },
--       paint(tex, item) draws an item's swatch, paintCurrent(tex) the closed one,
--       isSelected(item), onSelect(item) }
local function MakeDropdown(parent, o)
    local items = o.items
    local ITEM_H = 20
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(COLW, 22)

    local fs = Text(f)
    fs:SetPoint("LEFT")
    fs:SetText(o.label)

    local btn = CreateFrame("Button", nil, f, "BackdropTemplate")
    btn:SetPoint("TOPLEFT", f, "TOPLEFT", o.labelWidth or 58, 0)
    btn:SetPoint("BOTTOMRIGHT")
    Flat(btn, C.field, C.border, true)

    local cur = btn:CreateTexture(nil, "ARTWORK")
    cur:SetSize(16, 16)
    cur:SetPoint("LEFT", 4, 0)
    o.paintCurrent(cur)

    local arrow = btn:CreateTexture(nil, "ARTWORK")
    arrow:SetSize(18, 18)
    arrow:SetPoint("RIGHT", -1, 0)
    arrow:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
    arrow:SetTexCoord(0.2, 0.8, 0.2, 0.8)
    arrow:SetDesaturated(true)
    arrow:SetVertexColor(unpack(C.muted))

    local label = Text(btn, "GameFontHighlightSmall")
    label:SetPoint("LEFT", cur, "RIGHT", 6, 0)
    label:SetPoint("RIGHT", arrow, "LEFT", -2, 0)
    label:SetWordWrap(false)

    -- the open list (may be wider than the button so long names fit)
    local list = CreateFrame("Frame", nil, btn, "BackdropTemplate")
    list:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -2)
    if o.listWidth then
        list:SetWidth(o.listWidth)
    else
        list:SetPoint("TOPRIGHT", btn, "BOTTOMRIGHT", 0, -2)
    end
    list:SetHeight(#items * ITEM_H + 4)
    list:SetFrameStrata("FULLSCREEN_DIALOG")
    list:SetToplevel(true)
    list:EnableMouse(true)
    list:SetClampedToScreen(true)
    Flat(list, IsClassic() and { 0, 0, 0, 0.92 } or C.header, C.accent, false)
    list:Hide()

    local rowsUI = {}
    for i, item in ipairs(items) do
        local it = CreateFrame("Button", nil, list)
        it:SetHeight(ITEM_H)
        it:SetPoint("TOPLEFT", 2, -2 - (i - 1) * ITEM_H)
        it:SetPoint("RIGHT", list, "RIGHT", -2, 0)

        local hl = it:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.06)
        it.bar = it:CreateTexture(nil, "ARTWORK")
        it.bar:SetPoint("TOPLEFT")
        it.bar:SetPoint("BOTTOMLEFT")
        it.bar:SetWidth(2)
        it.bar:SetColorTexture(unpack(C.accent))

        local t = it:CreateTexture(nil, "ARTWORK")
        t:SetSize(16, 16)
        t:SetPoint("LEFT", 6, 0)
        o.paint(t, item)

        it.text = Text(it, "GameFontHighlightSmall")
        it.text:SetPoint("LEFT", t, "RIGHT", 6, 0)
        it.text:SetPoint("RIGHT", -4, 0)
        it.text:SetWordWrap(false)
        it.text:SetText(item.label)

        it:SetScript("OnClick", function()
            PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
            list:Hide()
            o.onSelect(item)
        end)
        it.item = item
        rowsUI[i] = it
    end

    -- Close when clicking anywhere else. Clients without GLOBAL_MOUSE_DOWN
    -- fall back to closing shortly after the mouse leaves.
    local hasGlobalClick = pcall(list.RegisterEvent, list, "GLOBAL_MOUSE_DOWN")
    list:UnregisterAllEvents()
    local away = 0
    list:SetScript("OnEvent", function(self)
        if not self:IsMouseOver() and not btn:IsMouseOver() then self:Hide() end
    end)
    list:SetScript("OnShow", function(self)
        away = 0
        if hasGlobalClick then self:RegisterEvent("GLOBAL_MOUSE_DOWN") end
        btn:SetBackdropBorderColor(unpack(C.accent))
    end)
    list:SetScript("OnHide", function(self)
        self:UnregisterAllEvents()
        btn:SetBackdropBorderColor(unpack(C.border))
    end)
    if not hasGlobalClick then
        list:SetScript("OnUpdate", function(self, elapsed)
            if self:IsMouseOver(4, -4, -4, 4) or btn:IsMouseOver() then
                away = 0
            else
                away = away + elapsed
                if away > 1.5 then self:Hide() end
            end
        end)
    end
    parent:HookScript("OnHide", function() list:Hide() end)

    btn:SetScript("OnClick", function()
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION or 852)
        list:SetShown(not list:IsShown())
    end)
    btn:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(unpack(C.accent))
        self:SetBackdropColor(unpack(C.button))
    end)
    btn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(unpack(C.field))
        if not list:IsShown() then self:SetBackdropBorderColor(unpack(C.border)) end
    end)

    function f:Refresh()
        local name = o.fallbackName or ""
        for _, it in ipairs(rowsUI) do
            local sel = o.isSelected(it.item)
            it.bar:SetShown(sel)
            it.text:SetTextColor(unpack(sel and C.accent or C.text))
            if sel then name = it.item.label end
        end
        label:SetText(name)
        o.paintCurrent(cur)
    end
    f.button = btn
    return f
end

-- Drawer button icon: the preset icons.
local function MakeIconDropdown(parent)
    local items = {}
    for _, p in ipairs(MBD.ICON_PRESETS) do tinsert(items, { value = p.path, label = p.label }) end
    local registered = false
    return MakeDropdown(parent, {
        label = "Icon",
        items = items,
        fallbackName = "Custom", -- an icon saved by an older version
        paint = function(t, item)
            t:SetTexture(item.value)
            t:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        end,
        paintCurrent = function(t)
            if registered then return end
            registered = true
            t:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            MBD:RegisterIconTexture(t)
        end,
        isSelected = function(item) return SameIcon(item.value, MBD.db.drawerIcon) end,
        onSelect = function(item) SetDrawerIcon(item.value) end,
    })
end

-- Background texture of the pop-out drawer.
local function MakeTextureDropdown(parent)
    local items = {}
    for _, t in ipairs(MBD.PANEL_TEXTURES) do tinsert(items, { value = t.key, label = t.label, preset = t }) end
    return MakeDropdown(parent, {
        label = "Background",
        labelWidth = 76,
        listWidth = 150,
        items = items,
        paint = function(tex, item) MBD:PaintSwatch(tex, item.preset) end,
        paintCurrent = function(tex) MBD:PaintSwatch(tex, MBD:GetPanelTexture()) end,
        isSelected = function(item) return item.value == MBD:GetPanelTexture().key end,
        onSelect = function(item)
            MBD.db.panelTexture = item.value
            MBD:ApplyPanelTexture()
            MBD:RefreshConfig()
        end,
    })
end

local function SectionTitle(parent, text, y)
    local fs = parent:CreateFontString(nil, "ARTWORK", IsClassic() and "GameFontNormal" or "GameFontNormalSmall")
    fs:SetPoint("TOPLEFT", PAD, y)
    fs:SetText(IsClassic() and text or text:upper())
    fs:SetTextColor(unpack(C.title))
    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetHeight(1)
    line:SetPoint("LEFT", fs, "RIGHT", 10, 0)
    line:SetPoint("RIGHT", parent, "RIGHT", -PAD, 0)
    line:SetColorTexture(unpack(C.line))
    return fs
end

local function ButtonIcon(f)
    if not f then return 134400 end
    -- same icon the drawer's uniform skin uses
    local tex = MBD:GetButtonIcon(f)
    if type(tex) == "table" and tex.GetTexture then
        local t = tex:GetTexture()
        if t then return t end
    end
    for _, region in ipairs({ f:GetRegions() }) do
        if region.GetObjectType and region:GetObjectType() == "Texture" then
            local t = region:GetTexture()
            if type(t) == "number" then return t end
            if type(t) == "string" then
                local lt = t:lower()
                if not lt:find("border") and not lt:find("background") and not lt:find("highlight") then
                    return t
                end
            end
        end
    end
    return 134400 -- question mark
end

--------------------------------------------------------------------------
-- Drag and drop reordering
--------------------------------------------------------------------------

local function CursorGap(count)
    local _, cy = GetCursorPosition()
    cy = cy / content:GetEffectiveScale()
    local top = content:GetTop()
    if not top then return 1 end
    local idx = math.floor((top - cy) / ROW_HEIGHT + 0.5) + 1
    return math.max(1, math.min(count + 1, idx))
end

local function DragUpdate()
    if not drag then return end
    local count = #MBD:GetConfigList()

    -- auto-scroll near the edges of the list
    local _, cy = GetCursorPosition()
    cy = cy / scroll:GetEffectiveScale()
    local st, sb = scroll:GetTop(), scroll:GetBottom()
    if st and sb then
        local cur, maxS = scroll:GetVerticalScroll(), scroll:GetVerticalScrollRange()
        if cy > st - 14 then
            scroll:SetVerticalScroll(math.max(0, cur - 6))
        elseif cy < sb + 14 then
            scroll:SetVerticalScroll(math.min(maxS, cur + 6))
        end
    end

    local gap = CursorGap(count)
    drag.gap = gap
    local y = -(gap - 1) * ROW_HEIGHT + 1
    dropLine:ClearAllPoints()
    dropLine:SetPoint("TOPLEFT", content, "TOPLEFT", 4, y)
    dropLine:SetPoint("TOPRIGHT", content, "TOPRIGHT", -4, y)
    dropLine:Show()

    local x, my = GetCursorPosition()
    local s = UIParent:GetEffectiveScale()
    ghost:ClearAllPoints()
    ghost:SetPoint("LEFT", UIParent, "BOTTOMLEFT", x / s + 14, my / s)
end

local function StartDrag(row)
    drag = { from = row.index }
    ghost.icon:SetTexture(row.icon:GetTexture())
    ghost.text:SetText(row.name)
    ghost:SetWidth(ghost.text:GetStringWidth() + 44)
    ghost:Show()
    row:SetAlpha(0.3)
    win:SetScript("OnUpdate", DragUpdate)
end

local function StopDrag(row)
    if not drag then return end
    win:SetScript("OnUpdate", nil)
    dropLine:Hide()
    ghost:Hide()
    row:SetAlpha(1)
    local from, gap = drag.from, drag.gap or drag.from
    drag = nil
    local to = (gap > from) and (gap - 1) or gap
    if to ~= from then MBD:MoveButton(from, to) end
    MBD:RefreshOptions()
end

--------------------------------------------------------------------------
-- List rows
--------------------------------------------------------------------------

local function GetRow(i)
    if rows[i] then return rows[i] end
    local row = CreateFrame("Frame", nil, content)
    row:SetHeight(ROW_HEIGHT)
    row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_HEIGHT)
    row:SetPoint("RIGHT", content, "RIGHT")
    row:EnableMouse(true)
    row:RegisterForDrag("LeftButton")
    row:SetScript("OnDragStart", StartDrag)
    row:SetScript("OnDragStop", StopDrag)

    local stripe = row:CreateTexture(nil, "BACKGROUND")
    stripe:SetAllPoints()
    stripe:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.025 or 0)

    local hl = row:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.045)
    local hlBar = row:CreateTexture(nil, "HIGHLIGHT")
    hlBar:SetPoint("TOPLEFT")
    hlBar:SetPoint("BOTTOMLEFT")
    hlBar:SetWidth(2)
    hlBar:SetColorTexture(unpack(C.accent))

    -- drag handle: 2x3 grip dots
    for gx = 0, 1 do
        for gy = 0, 2 do
            local t = row:CreateTexture(nil, "ARTWORK")
            t:SetSize(2, 2)
            t:SetPoint("CENTER", row, "LEFT", X_HANDLE - 2 + gx * 4, 4 - gy * 4)
            t:SetColorTexture(C.muted[1], C.muted[2], C.muted[3], 0.7)
        end
    end

    row.show = MakeToggle(row, nil, function(v)
        MBD.db.hidden[row.key] = (not v) or nil
        MBD:Layout()
        MBD:RefreshOptions()
    end)
    row.show:SetPoint("CENTER", row, "LEFT", X_SHOW, 0)
    Tooltip(row.show, "Show", "Include this button in the drop-down.")

    row.collect = MakeToggle(row, nil, function(v)
        if v then
            MBD.db.ignored[row.key] = nil
        else
            MBD.db.ignored[row.key] = true
            MBD:ReleaseButton(row.key)
        end
        MBD:Scan()
        MBD:Layout()
    end)
    row.collect:SetPoint("CENTER", row, "LEFT", X_COLLECT, 0)
    Tooltip(row.collect, "Collect",
        "Checked: the button lives in the drawer.\nUnchecked: the button returns to its normal spot on the minimap.")

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(18, 18)
    row.icon:SetPoint("LEFT", X_ICON, 0)
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    row.status = Text(row, "GameFontHighlightSmall", C.muted)
    row.status:SetPoint("RIGHT", -10, 0)
    row.status:SetJustifyH("RIGHT")

    row.text = Text(row)
    row.text:SetPoint("LEFT", row.icon, "RIGHT", 8, 0)
    row.text:SetPoint("RIGHT", row.status, "LEFT", -8, 0)
    row.text:SetWordWrap(false)

    rows[i] = row
    return row
end

function MBD:RefreshOptions()
    if not content or not self.known then return end
    local list = self:GetConfigList()
    local shown = 0
    for i, name in ipairs(list) do
        local row = GetRow(i)
        local f = self.buttons[name] or _G[name]
        row.key, row.index, row.name = name, i, self:PrettyName(name)
        local collected = not self.db.ignored[name]
        local visible = collected and not self.db.hidden[name]
        row.collect:SetChecked(collected)
        row.show:SetChecked(not self.db.hidden[name])
        row.show:SetEnabled(collected)
        row.icon:SetTexture(ButtonIcon(f))
        row.icon:SetDesaturated(not visible)
        row.icon:SetAlpha(visible and 1 or 0.5)
        row.text:SetText(row.name)
        row.text:SetTextColor(unpack(visible and C.text or C.muted))
        if not collected then
            row.status:SetText("On minimap")
        elseif self.db.hidden[name] then
            row.status:SetText("Hidden")
        else
            row.status:SetText("")
            shown = shown + 1
        end
        row:SetAlpha(1)
        row:Show()
    end
    for i = #list + 1, #rows do rows[i]:Hide() end
    content:SetHeight(math.max(10, #list * ROW_HEIGHT))
    if countText then
        countText:SetText(("|cff%s%d|r of |cff%s%d|r buttons shown in the drawer"):format(
            TEXT_HEX, shown, TEXT_HEX, #list))
    end
end

function MBD:RefreshConfig()
    if not win then return end
    for _, c in pairs(controls) do
        if c.Refresh then c:Refresh() end
    end
    self:RefreshOptions()
end

local function RestoreDefaults()
    local D = MBD.DEFAULTS
    for _, k in ipairs({ "locked", "autoClose", "closeOnClick", "columns", "buttonSize", "direction",
                         "drawerSize", "drawerIcon", "spacing", "uniformStyle", "bronzeRings", "panelTexture" }) do
        MBD.db[k] = D[k]
    end
    MBD:Layout()
    MBD:ApplyDrawerStyle()
    MBD:ApplyPanelTexture()
    MBD:RefreshConfig()
end

--------------------------------------------------------------------------
-- Window
--------------------------------------------------------------------------

local specialAdded

local function BuildWindow()
    ApplyTheme(MBD.db.windowStyle)
    -- Classic: use the game's own window template, so the client draws it in
    -- its native style (WoW Forever's frames on Forever) - opaque, with a
    -- title bar and close button.
    local templated = false
    if IsClassic() then
        -- BasicFrameTemplate (no inset frame): its background is drawn on the
        -- window itself, underneath our labels, rather than on a child frame above them.
        local ok, f = pcall(CreateFrame, "Frame", "MinimapButtonDrawerConfig", UIParent, "BasicFrameTemplate")
        if ok and f then
            win, templated = f, true
            if type(win.Inset) == "table" and win.Inset.Hide then win.Inset:Hide() end
        end
    end
    if not templated then
        win = CreateFrame("Frame", "MinimapButtonDrawerConfig", UIParent, "BackdropTemplate")
    end
    win:SetSize(WIDTH, HEIGHT)
    win:SetPoint("CENTER")
    win:SetFrameStrata("DIALOG")
    win:SetToplevel(true)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:EnableMouse(true)
    if templated then
        -- the template draws everything
    elseif IsClassic() then
        win:SetBackdrop(CLASSIC_WINDOW)
        win:SetBackdropColor(0.09, 0.08, 0.07, 1)
        win:SetBackdropBorderColor(1, 1, 1, 1)
    else
        Flat(win, C.bg, C.border)
    end
    win:Hide()
    if not specialAdded then
        tinsert(UISpecialFrames, "MinimapButtonDrawerConfig")
        specialAdded = true
    end

    -- Title bar (drag to move) ------------------------------------------
    local header = CreateFrame("Frame", nil, win)
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(38)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() win:StartMoving() end)
    header:SetScript("OnDragStop", function() win:StopMovingOrSizing() end)

    local hbg = header:CreateTexture(nil, "BACKGROUND")
    hbg:SetAllPoints()
    hbg:SetColorTexture(unpack(C.header))
    local hline = header:CreateTexture(nil, "ARTWORK")
    hline:SetPoint("BOTTOMLEFT")
    hline:SetPoint("BOTTOMRIGHT")
    hline:SetHeight(1)
    hline:SetColorTexture(unpack(C.line))
    if IsClassic() then hbg:Hide(); hline:Hide() end

    local hicon = header:CreateTexture(nil, "ARTWORK")
    hicon:SetSize(20, 20)
    hicon:SetPoint("LEFT", PAD - 2, 0)
    hicon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    MBD:RegisterIconTexture(hicon)

    local title = header:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    title:SetText("Minimap Button Drawer")
    local version = GetMeta and GetMeta(ADDON, "Version")
    local vfs
    if version then
        vfs = header:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        vfs:SetText("v" .. version)
        vfs:SetTextColor(unpack(C.muted))
    end

    if templated then
        -- title in the template's title bar; drag strip = title bar only
        header:SetHeight(22)
        header:SetPoint("TOPRIGHT", -26, -1)
        local tt = win.TitleText or win.title
        if type(tt) == "table" and tt.SetText then
            tt:SetText("Minimap Button Drawer")
            title:Hide()
        else
            title:SetPoint("TOP", win, "TOP", 0, -5)
        end
        hicon:SetSize(16, 16)
        hicon:ClearAllPoints()
        hicon:SetPoint("TOPLEFT", win, "TOPLEFT", 7, -4)
        if vfs then vfs:SetPoint("TOPRIGHT", win, "TOPRIGHT", -30, -7) end
        local cb = win.CloseButton
        if not (type(cb) == "table" and cb.SetFrameLevel) then
            cb = CreateFrame("Button", nil, win, "UIPanelCloseButton")
            cb:SetPoint("TOPRIGHT", 2, 1)
        end
        cb:SetScript("OnClick", function() win:Hide() end)
        cb:SetFrameLevel(header:GetFrameLevel() + 5)
    elseif IsClassic() then
        -- gold title plate on the top edge, Blizzard close button
        local plate = header:CreateTexture(nil, "ARTWORK")
        plate:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
        plate:SetSize(320, 64)
        plate:SetPoint("TOP", win, "TOP", 0, 12)
        title:SetPoint("TOP", plate, "TOP", 0, -14)
        hicon:SetPoint("LEFT", PAD + 2, -2)
        if vfs then vfs:SetPoint("LEFT", hicon, "RIGHT", 6, 0) end
        local close = CreateFrame("Button", nil, header, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", win, "TOPRIGHT", -4, -4)
        close:SetScript("OnClick", function() win:Hide() end)
    else
        title:SetPoint("LEFT", hicon, "RIGHT", 10, 0)
        title:SetTextColor(1, 1, 1)
        if vfs then vfs:SetPoint("LEFT", title, "RIGHT", 8, 0) end
    end

    local close = CreateFrame("Button", nil, header)
    close:SetShown(not IsClassic())
    close:SetSize(24, 24)
    close:SetPoint("RIGHT", -8, 0)
    local closeBg = close:CreateTexture(nil, "BACKGROUND")
    closeBg:SetAllPoints()
    closeBg:SetColorTexture(1, 1, 1, 0)
    local x = close:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    x:SetPoint("CENTER", 0, 0)
    x:SetText("X")
    x:SetTextColor(unpack(C.muted))
    close:SetScript("OnEnter", function()
        closeBg:SetColorTexture(0.75, 0.22, 0.20, 0.9)
        x:SetTextColor(1, 1, 1)
    end)
    close:SetScript("OnLeave", function()
        closeBg:SetColorTexture(1, 1, 1, 0)
        x:SetTextColor(unpack(C.muted))
    end)
    close:SetScript("OnClick", function() win:Hide() end)

    -- Behavior ------------------------------------------------------------
    SectionTitle(win, "Behavior", -54)

    local lock = MakeToggle(win, "Lock drawer button", function(v) MBD.db.locked = v end)
    lock:SetPoint("TOPLEFT", PAD + 2, -76)
    function lock:Refresh() self:SetChecked(MBD.db.locked) end
    controls.lock = lock
    Tooltip(lock, "Lock drawer button",
        "Prevents the drawer button from being dragged around the minimap edge.")

    local closeOnClick = MakeToggle(win, "Close after a click", function(v) MBD.db.closeOnClick = v end)
    closeOnClick:SetPoint("TOPLEFT", COL2, -76)
    function closeOnClick:Refresh() self:SetChecked(MBD.db.closeOnClick) end
    controls.closeOnClick = closeOnClick
    Tooltip(closeOnClick, "Close after a click",
        "Closes the drop-down when you click one of the buttons inside it. Turn off to click several in a row.")

    local autoClose = MakeToggle(win, "Close when mouse leaves", function(v) MBD.db.autoClose = v end)
    autoClose:SetPoint("TOPLEFT", PAD + 2, -102)
    function autoClose:Refresh() self:SetChecked(MBD.db.autoClose) end
    controls.autoClose = autoClose
    Tooltip(autoClose, "Close when mouse leaves",
        "Closes the drop-down about a second after the mouse moves away. Turn off to keep it open until you click the drawer button again.")

    local classic = MakeToggle(win, "Classic window style", function(v)
        C_Timer.After(0, function() MBD:SetWindowStyle(v and "classic" or "modern") end)
    end)
    classic:SetPoint("TOPLEFT", COL2, -102)
    function classic:Refresh() self:SetChecked(MBD.db.windowStyle == "classic") end
    controls.classic = classic
    Tooltip(classic, "Classic window style",
        "Use Blizzard's own frame style for this window (dialog border, gold headings, red buttons) instead of the modern flat look.")

    -- Layout --------------------------------------------------------------
    SectionTitle(win, "Layout", -134)

    local cols = MakeStepper(win, "Buttons per row", 1, 12, 1,
        function() return MBD.db.columns end,
        function(v) MBD.db.columns = v; MBD:Layout() end)
    cols:SetPoint("TOPLEFT", PAD + 2, -154)
    cols:SetWidth(COL2 - PAD - 2 - 20)
    controls.cols = cols

    local size = MakeStepper(win, "Icon size", 20, 48, 2,
        function() return MBD.db.buttonSize end,
        function(v) MBD.db.buttonSize = v; MBD:Layout() end)
    size:SetPoint("TOPLEFT", COL2, -154)
    controls.size = size

    local spacing = MakeStepper(win, "Icon spacing", 0, 24, 1,
        function() return MBD.db.spacing end,
        function(v) MBD.db.spacing = v; MBD:Layout() end)
    spacing:SetPoint("TOPLEFT", PAD + 2, -184)
    spacing:SetWidth(COL2 - PAD - 2 - 20)
    controls.spacing = spacing

    local uniform = MakeToggle(win, "Uniform button rings", function(v)
        MBD.db.uniformStyle = v
        MBD:Layout()
    end)
    uniform:SetPoint("TOPLEFT", COL2, -187)
    function uniform:Refresh() self:SetChecked(MBD.db.uniformStyle) end
    controls.uniform = uniform
    Tooltip(uniform, "Uniform button rings",
        "Gives every button in the drawer the same ring, background and icon size. Turn off to show each addon's own button art.")

    local background = MakeTextureDropdown(win)
    background:SetPoint("TOPLEFT", PAD + 2, -216)
    background:SetWidth(COL2 - PAD - 2 - 20)
    controls.background = background
    Tooltip(background.button, "Drawer background",
        "The texture behind the buttons in the pop-out drawer.")

    local bronze = MakeToggle(win, "Bronze rings", function(v)
        MBD.db.bronzeRings = v
        MBD:RefreshRings()
    end)
    bronze:SetPoint("TOPLEFT", COL2, -219)
    function bronze:Refresh() self:SetChecked(MBD.db.bronzeRings == true) end
    controls.bronze = bronze
    Tooltip(bronze, "Bronze rings",
        "Tints the drawer button's ring and the uniform rings bronze, to match WoW Forever's minimap buttons. Turn off for the texture's original gold.")

    local dirLabel = Text(win)
    dirLabel:SetPoint("TOPLEFT", PAD + 2, -254)
    dirLabel:SetText("Expand direction")
    local dirHint = Text(win, "GameFontHighlightSmall", C.muted)
    dirHint:SetPoint("TOPLEFT", dirLabel, "BOTTOMLEFT", 0, -5)
    dirHint:SetWidth(COL2 - PAD - 24)
    dirHint:SetSpacing(2)
    dirHint:SetText("Where the drop-down opens relative to the drawer button.")

    local picker = MakeDirectionPicker(win)
    picker:SetPoint("TOPLEFT", COL2, -250)
    controls.picker = picker

    -- Drawer button -------------------------------------------------------
    SectionTitle(win, "Drawer button", -330)

    local dsize = MakeStepper(win, "Button size", MBD.SIZE_MIN, MBD.SIZE_MAX, 2,
        function() return MBD.db.drawerSize end,
        function(v) MBD.db.drawerSize = v; MBD:ApplyDrawerStyle() end)
    dsize:SetPoint("TOPLEFT", PAD + 2, -350)
    dsize:SetWidth(COL2 - PAD - 2 - 20)
    controls.dsize = dsize

    local iconPicker = MakeIconDropdown(win)
    iconPicker:SetPoint("TOPLEFT", COL2, -350)
    controls.iconPicker = iconPicker

    -- Addon buttons -------------------------------------------------------
    SectionTitle(win, "Addon buttons", -392)

    local bw = math.floor((WIDTH - 2 * PAD - 3 * 6) / 4)
    local rescan = MakeButton(win, "Rescan", bw, function() MBD:Scan(); MBD:Layout() end)
    rescan:SetPoint("TOPLEFT", PAD, -412)
    local sortAZ = MakeButton(win, "Sort A-Z", bw, function()
        wipe(MBD.db.order); MBD:UpdateOrder(); MBD:Layout(); MBD:RefreshOptions()
    end)
    sortAZ:SetPoint("LEFT", rescan, "RIGHT", 6, 0)
    local showAll = MakeButton(win, "Show all", bw, function()
        wipe(MBD.db.hidden); MBD:Layout(); MBD:RefreshOptions()
    end)
    showAll:SetPoint("LEFT", sortAZ, "RIGHT", 6, 0)
    local hideAll = MakeButton(win, "Hide all", bw, function()
        for _, n in ipairs(MBD.order) do MBD.db.hidden[n] = true end
        MBD:Layout(); MBD:RefreshOptions()
    end)
    hideAll:SetPoint("LEFT", showAll, "RIGHT", 6, 0)

    -- list with a column header strip
    local listBg = CreateFrame("Frame", nil, win, "BackdropTemplate")
    listBg:SetPoint("TOPLEFT", PAD, -444)
    listBg:SetPoint("BOTTOMRIGHT", -PAD, 82)
    Flat(listBg, C.field, C.border)

    local colHeader = CreateFrame("Frame", nil, listBg)
    colHeader:SetPoint("TOPLEFT", 1, -1)
    colHeader:SetPoint("TOPRIGHT", -1, -1)
    colHeader:SetHeight(22)
    local chbg = colHeader:CreateTexture(nil, "BACKGROUND")
    chbg:SetAllPoints()
    chbg:SetColorTexture(unpack(C.header))
    local chline = colHeader:CreateTexture(nil, "ARTWORK")
    chline:SetPoint("BOTTOMLEFT")
    chline:SetPoint("BOTTOMRIGHT")
    chline:SetHeight(1)
    chline:SetColorTexture(unpack(C.line))
    -- rows sit 1px inside listBg, same as this strip, so the x offsets line up
    local function ColLabel(text, xPos, leftAligned)
        local fs = colHeader:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
        fs:SetText(text)
        fs:SetTextColor(unpack(C.muted))
        fs:SetPoint(leftAligned and "LEFT" or "CENTER", colHeader, "LEFT", xPos, 0)
    end
    ColLabel("SHOW", X_SHOW)
    ColLabel("COLLECT", X_COLLECT)
    ColLabel("ADDON", X_ICON, true)

    -- UIPanelScrollFrameTemplate is the old template; newer retail builds may
    -- only have ScrollFrameTemplate, so fall back to it.
    local okScroll, sf = pcall(CreateFrame, "ScrollFrame", nil, listBg, "UIPanelScrollFrameTemplate")
    if not (okScroll and sf) then
        okScroll, sf = pcall(CreateFrame, "ScrollFrame", nil, listBg, "ScrollFrameTemplate")
    end
    scroll = (okScroll and sf) or CreateFrame("ScrollFrame", nil, listBg)
    if not (okScroll and sf) then scroll:EnableMouseWheel(true) end
    scroll:SetScript("OnMouseWheel", scroll:GetScript("OnMouseWheel") or function(self, delta)
        local v = self:GetVerticalScroll() - delta * ROW_HEIGHT * 2
        self:SetVerticalScroll(math.max(0, math.min(self:GetVerticalScrollRange(), v)))
    end)
    scroll:SetPoint("TOPLEFT", 1, -24)
    scroll:SetPoint("BOTTOMRIGHT", -24, 2)
    content = CreateFrame("Frame", nil, scroll)
    content:SetSize(WIDTH - 2 * PAD - 26, 10)
    scroll:SetScrollChild(content)
    scroll:SetScript("OnSizeChanged", function(_, w) content:SetWidth(w) end)

    dropLine = content:CreateTexture(nil, "OVERLAY")
    dropLine:SetHeight(2)
    dropLine:SetColorTexture(unpack(C.accent))
    dropLine:Hide()

    ghost = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    ghost:SetSize(200, 26)
    ghost:SetFrameStrata("TOOLTIP")
    Flat(ghost, C.header, C.accent)
    ghost.icon = ghost:CreateTexture(nil, "ARTWORK")
    ghost.icon:SetSize(18, 18)
    ghost.icon:SetPoint("LEFT", 5, 0)
    ghost.text = ghost:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    ghost.text:SetPoint("LEFT", ghost.icon, "RIGHT", 8, 0)
    ghost:Hide()

    -- short hint under the list
    local hint = Text(win, "GameFontHighlightSmall", C.muted)
    hint:SetPoint("TOPLEFT", listBg, "BOTTOMLEFT", 2, -8)
    hint:SetPoint("RIGHT", win, "RIGHT", -PAD, 0)
    hint:SetSpacing(2)
    hint:SetText("Drag rows by the handle to reorder. Unchecking Collect returns a button to the minimap; some addons need a |cff" ..
        TEXT_HEX .. "/reload|r.")

    -- Footer --------------------------------------------------------------
    local footLine = win:CreateTexture(nil, "ARTWORK")
    footLine:SetHeight(1)
    local inset = templated and 6 or (IsClassic() and 12 or 1) -- stay inside the border
    footLine:SetPoint("BOTTOMLEFT", inset, 38)
    footLine:SetPoint("BOTTOMRIGHT", -inset, 38)
    footLine:SetColorTexture(unpack(C.line))

    countText = Text(win, "GameFontHighlightSmall", C.muted)
    countText:SetPoint("BOTTOMLEFT", PAD, 15)

    local defaults = MakeButton(win, "Restore defaults", 120, RestoreDefaults)
    defaults:SetPoint("BOTTOMRIGHT", -PAD, 8)
    Tooltip(defaults, "Restore defaults",
        "Resets the Behavior, Layout and Drawer button settings (except the window style). Your button order and show/collect choices are kept.")

    win:SetScript("OnShow", function()
        MBD:Scan()
        MBD:RefreshConfig()
    end)
    win:SetScript("OnHide", function()
        if drag then
            win:SetScript("OnUpdate", nil)
            drag = nil; dropLine:Hide(); ghost:Hide()
        end
    end)
end

function MBD:ToggleConfig()
    if not win then BuildWindow() end
    win:SetShown(not win:IsShown())
end

-- Switching style rebuilds the window in place (same position, same open state).
function MBD:SetWindowStyle(style)
    self.db.windowStyle = (style == "classic") and "classic" or "modern"
    local wasShown, point = false, nil
    if win then
        wasShown = win:IsShown()
        if win:GetNumPoints() > 0 then point = { win:GetPoint(1) } end
        win:SetScript("OnHide", nil)
        win:Hide()
        if ghost then ghost:Hide() end
    end
    win, content, scroll, dropLine, ghost, countText, drag = nil, nil, nil, nil, nil, nil, nil
    rows, controls = {}, {}
    -- forget the old window's copies of the drawer icon (index 1 is the drawer itself)
    for i = #self.iconTextures, 2, -1 do self.iconTextures[i] = nil end
    BuildWindow()
    if point and point[1] then
        win:ClearAllPoints()
        win:SetPoint(unpack(point))
    end
    if wasShown then win:Show() end
end

function MBD:OpenOptions()
    if not win then BuildWindow() end
    win:Show()
end

--------------------------------------------------------------------------
-- Small entry in Esc > Options > AddOns that opens the window
--------------------------------------------------------------------------

function MBD:CreateOptions()
    local frame = CreateFrame("Frame")
    frame.name = "Minimap Button Drawer"
    frame.OnCommit = function() end
    frame.OnDefault = function() end
    frame.OnRefresh = function() end

    local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Minimap Button Drawer")

    local text = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    text:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    text:SetText("Right-click the drawer button or type /mbd to open the settings window.")

    local open = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    open:SetSize(140, 22)
    open:SetText("Open settings")
    open:SetScript("OnClick", function()
        if SettingsPanel and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
        MBD:OpenOptions()
    end)
    open:SetPoint("TOPLEFT", text, "BOTTOMLEFT", 0, -12)

    if Settings and Settings.RegisterCanvasLayoutCategory then
        local category = Settings.RegisterCanvasLayoutCategory(frame, frame.name)
        Settings.RegisterAddOnCategory(category)
    end
end

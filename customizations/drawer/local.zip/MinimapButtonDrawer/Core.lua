local zhTW = GetLocale() == "zhTW"
local function Z(english, chinese)
    if zhTW then return chinese end
    return english
end

-- Minimap Button Drawer
-- Collects addon minimap buttons into a single drop-down drawer.

local ADDON, ns = ...
local MBD = CreateFrame("Frame", "MinimapButtonDrawerFrame")
ns.MBD = MBD

local DEFAULTS = {
    angle = 200,          -- position of the drawer button around the minimap
    columns = 5,          -- buttons per row in the drop-down
    buttonSize = 32,
    spacing = 4,
    autoClose = true,     -- close drop-down when the mouse leaves it
    closeOnClick = true,  -- close drop-down after clicking a collected button
    hidden = {},          -- [buttonName] = true -> not shown in the drop-down
    ignored = {},         -- [buttonName] = true -> left alone on the minimap
    order = {},           -- user-defined button order (list of names)
    locked = false,       -- drawer button can't be dragged
    direction = "AUTO",   -- which way the drop-down expands from the drawer button
    drawerSize = 32,      -- size of the drawer button on the minimap, in pixels (same unit as buttonSize)
    drawerIcon = "Interface\\Icons\\INV_Misc_Bag_08", -- texture path or file ID
    uniformStyle = true,  -- give every collected button the same ring and icon size
    windowStyle = "modern", -- config window look: "modern" or "classic"
    bronzeRings = false,  -- tint the rings bronze (WoW Forever) instead of the texture's gold
    panelTexture = "dark", -- background of the pop-out drawer (key into PANEL_TEXTURES)
}

local DEFAULT_ICON = DEFAULTS.drawerIcon
local SIZE_MIN, SIZE_MAX = 16, 64 -- drawer button size range, in pixels
local DRAWER_BASE = 32             -- the drawer frame's unscaled size
MBD.SIZE_MIN, MBD.SIZE_MAX = SIZE_MIN, SIZE_MAX

-- Icons offered in the config window (all exist in every client version).
MBD.ICON_PRESETS = {
    { path = "Interface\\Icons\\INV_Misc_Bag_08", label = Z("Bag (default)", "背包（預設）") },
    { path = "Interface\\Icons\\INV_Misc_Bag_07", label = Z("Bag 2", "背包 2") },
    { path = "Interface\\Icons\\INV_Misc_Bag_10", label = Z("Bag 3", "背包 3") },
    { path = "Interface\\Icons\\INV_Box_01", label = Z("Box", "箱子") },
    { path = "Interface\\Icons\\INV_Misc_Gear_01", label = Z("Gear", "齒輪") },
    { path = "Interface\\Icons\\Trade_Engineering", label = Z("Engineering", "工程學") },
    { path = "Interface\\Icons\\INV_Misc_Book_09", label = Z("Book", "書本") },
    { path = "Interface\\Icons\\INV_Misc_Note_01", label = Z("Note", "筆記") },
    { path = "Interface\\Icons\\INV_Misc_Map_01", label = Z("Map", "地圖") },
    { path = "Interface\\Icons\\INV_Misc_Spyglass_02", label = Z("Spyglass", "望遠鏡") },
    { path = "Interface\\Icons\\Ability_Tracking", label = Z("Tracking", "追蹤") },
    { path = "Interface\\Icons\\INV_Misc_Key_03", label = Z("Key", "鑰匙") },
    { path = "Interface\\Icons\\INV_Misc_Coin_01", label = Z("Coin", "硬幣") },
    { path = "Interface\\Icons\\INV_Misc_Rune_01", label = Z("Rune", "符文") },
    { path = "Interface\\Icons\\Spell_Holy_MagicalSentry", label = Z("Magical sentry", "魔法哨兵") },
    { path = "Interface\\Icons\\INV_Misc_QuestionMark", label = Z("Question mark", "問號") },
}

-- Backgrounds offered for the pop-out drawer. bg = tiled background file,
-- color = its tint (alpha = transparency), border = edge art (nil = none).
local TOOLTIP_BG     = "Interface\\Tooltips\\UI-Tooltip-Background"
local TOOLTIP_BORDER = "Interface\\Tooltips\\UI-Tooltip-Border"
local WHITE_TEX      = "Interface\\Buttons\\WHITE8X8"
MBD.PANEL_TEXTURES = {
    { key = "dark", label = Z("Dark transparent", "深色半透明"), bg = TOOLTIP_BG, color = { 0, 0, 0, 0.6 },
      border = TOOLTIP_BORDER, borderColor = { 0.45, 0.45, 0.45, 0.9 } },
    { key = "darksolid", label = Z("Dark solid", "深色實底"), bg = TOOLTIP_BG, color = { 0.04, 0.04, 0.05, 1 },
      border = TOOLTIP_BORDER, borderColor = { 0.5, 0.5, 0.5, 1 } },
    { key = "glass", label = Z("Light glass", "淺色玻璃"), bg = TOOLTIP_BG, color = { 0.55, 0.57, 0.62, 0.22 } }, -- no border
    { key = "rock", label = Z("Rock", "岩石"), bg = "Interface\\FrameGeneral\\UI-Background-Rock",
      tileSize = 128, color = { 1, 1, 1, 1 }, border = TOOLTIP_BORDER, borderColor = { 0.6, 0.6, 0.6, 1 } },
    -- Dark warm fill inside a flat bronze frame (dark line, bronze band, dark line, black line),
    -- like WoW Forever's menus. bands = nested edges from the outside in: { width, r, g, b }.
    { key = "bronze", label = Z("Bronze frame", "青銅外框"), bg = WHITE_TEX, color = { 0.106, 0.090, 0.075, 0.97 },
      pad = 10, swatchBorder = { 0.62, 0.49, 0.34 },
      bands = { { 1, 0.17, 0.11, 0.01 }, { 2, 0.62, 0.49, 0.34 }, { 1, 0.22, 0.12, 0.02 }, { 1, 0, 0, 0 } } },
    { key = "none", label = Z("None", "無") },
}

-- Space between the drawer's edge and the first row/column of buttons.
function MBD:GetPanelPad()
    return self:GetPanelTexture().pad or 8
end

function MBD:GetPanelTexture(key)
    key = key or (self.db and self.db.panelTexture)
    for _, t in ipairs(self.PANEL_TEXTURES) do
        if t.key == key then return t end
    end
    return self.PANEL_TEXTURES[1]
end

-- Show a preset on a small texture (used by the config dropdown).
function MBD:PaintSwatch(tex, t)
    if t and t.bg then
        tex:SetTexture(t.bg)
        tex:SetVertexColor(unpack(t.color or { 1, 1, 1, 1 }))
        -- a thin outline on the swatch for framed presets (e.g. Bronze frame)
        local parent = tex:GetParent()
        if parent and parent.CreateTexture then
            tex.mbdEdge = tex.mbdEdge or parent:CreateTexture(nil, "ARTWORK", nil, -1)
            tex.mbdEdge:ClearAllPoints()
            tex.mbdEdge:SetPoint("TOPLEFT", tex, -1, 1)
            tex.mbdEdge:SetPoint("BOTTOMRIGHT", tex, 1, -1)
            tex.mbdEdge:SetColorTexture(1, 1, 1, 1)
            if t.swatchBorder then
                tex.mbdEdge:SetVertexColor(unpack(t.swatchBorder))
                tex.mbdEdge:Show()
            else
                tex.mbdEdge:Hide()
            end
        end
        return
    else
        if tex.mbdEdge then tex.mbdEdge:Hide() end
        tex:SetColorTexture(0, 0, 0, 0)
    end
end

-- Where the drop-down opens relative to the drawer button.
-- point = panel anchor, rel = drawer anchor, x/y = gap, up = rows grow upward
local DIRECTIONS = {
    TOPLEFT     = { point = "BOTTOMRIGHT", rel = "TOPRIGHT",    x = 0,  y = 4,  up = true, label = Z("Top-left", "左上") },
    TOP         = { point = "BOTTOM",      rel = "TOP",         x = 0,  y = 4,  up = true, label = Z("Top", "上") },
    TOPRIGHT    = { point = "BOTTOMLEFT",  rel = "TOPLEFT",     x = 0,  y = 4,  up = true, label = Z("Top-right", "右上") },
    LEFT        = { point = "RIGHT",       rel = "LEFT",        x = -4, y = 0,  label = Z("Center-left", "左側") },
    RIGHT       = { point = "LEFT",        rel = "RIGHT",       x = 4,  y = 0,  label = Z("Center-right", "右側") },
    BOTTOMLEFT  = { point = "TOPRIGHT",    rel = "BOTTOMRIGHT", x = 0,  y = -4, label = Z("Bottom-left", "左下") },
    BOTTOM      = { point = "TOP",         rel = "BOTTOM",      x = 0,  y = -4, label = Z("Bottom", "下") },
    BOTTOMRIGHT = { point = "TOPLEFT",     rel = "BOTTOMLEFT",  x = 0,  y = -4, label = Z("Bottom-right", "右下") },
}
MBD.DIRECTIONS = DIRECTIONS
MBD.DEFAULTS = DEFAULTS

-- Blizzard / UI frames that should never be collected.
local BLACKLIST = {
    MinimapBackdrop = true, MinimapCompassTexture = true, MinimapCluster = true,
    MinimapZoomIn = true, MinimapZoomOut = true, MiniMapTracking = true,
    MiniMapTrackingButton = true, GameTimeFrame = true, TimeManagerClockButton = true,
    MiniMapMailFrame = true, MiniMapMailIcon = true, MinimapZoneTextButton = true,
    QueueStatusButton = true, QueueStatusMinimapButton = true, MiniMapWorldMapButton = true,
    ExpansionLandingPageMinimapButton = true, GarrisonLandingPageMinimapButton = true,
    AddonCompartmentFrame = true, MiniMapInstanceDifficulty = true,
    GuildInstanceDifficulty = true, MiniMapChallengeMode = true,
    MinimapButtonDrawerButton = true, MinimapButtonDrawerPanel = true,
    HybridMinimap = true, MinimapNorthTag = true, MiniMapBattlefieldFrame = true,
    MiniMapLFGFrame = true, MiniMapVoiceChatFrame = true, FeedbackUIButton = true,
    -- retail (Dragonflight and later)
    MiniMapCraftingOrderFrame = true, MinimapZoneText = true,
}

-- True for frames Blizzard's own UI created. A global set by the game's secure
-- code is untainted, while every addon-created global is tainted by its addon.
-- This keeps the drawer away from retail's many named minimap frames
-- (tracking, mail, crafting orders, landing page, housing...) whatever they are called.
local function IsBlizzardFrame(name)
    if not issecurevariable then return false end
    local ok, secure = pcall(issecurevariable, name)
    return ok and secure == true
end

-- Name patterns that belong to map pins / gathering nodes / Blizzard, not buttons.
local IGNORE_PATTERNS = {
    "^GatherMatePin", "^HandyNotesPin", "^TTMinimapButton", "Pin%d*$",
    "^QuestieFrame", "^Archy", "^GatherNote", "^ZGVMarker", "^TomTom",
    "^Minimap$", "^MinimapButtonDrawer", "^HBD%-Pins",
}

MBD.buttons = {}      -- [name] = frame
MBD.order = {}        -- sorted list of names
local hooked = {}     -- frames whose methods we already overrode
local orig = {}       -- [frame] = { SetPoint=, ClearAllPoints=, SetParent= }

--------------------------------------------------------------------------
-- Helpers
--------------------------------------------------------------------------

function MBD:PrettyName(name)
    local n = name:gsub("^LibDBIcon10_", "")
    n = n:gsub("_?[Mm]inimap[Bb]utton$", ""):gsub("MinimapIcon$", "")
    if n == "" then n = name end
    return n
end

local function IsIgnoredName(name)
    if BLACKLIST[name] then return true end
    for _, p in ipairs(IGNORE_PATTERNS) do
        if name:find(p) then return true end
    end
    return false
end

local function LooksLikeButton(f)
    if not f or f.IsForbidden and f:IsForbidden() then return false end
    if f.IsProtected and f:IsProtected() then return false end
    local name = f.GetName and f:GetName()
    if not name or IsIgnoredName(name) then return false end
    if name:find("^LibDBIcon10_") then return true end
    if IsBlizzardFrame(name) then return false end
    if not (f.GetObjectType and (f:GetObjectType() == "Button" or f:GetObjectType() == "Frame")) then
        return false
    end
    local w, h = f:GetSize()
    if not w or w < 14 or w > 48 or h < 14 or h > 48 then return false end
    local lname = name:lower()
    if lname:find("minimap") or lname:find("button") or lname:find("icon") then
        return f:HasScript("OnClick") or f:HasScript("OnMouseUp") or f:HasScript("OnMouseDown")
    end
    return false
end

--------------------------------------------------------------------------
-- Drawer button (sits on the minimap edge)
--------------------------------------------------------------------------

-- Ring geometry, shared by the drawer button and the "uniform" skin for
-- collected buttons. Measured for a 32px button (Blizzard's own tracking
-- button layout): the ring's hole is centred on the button, the dark
-- background fills the hole completely and the icon sits inside it.
local RING_TEX = "Interface\\Minimap\\MiniMap-TrackingBorder"
local BG_TEX   = "Interface\\Minimap\\UI-Minimap-Background"
local MASK_TEX = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local RING_SIZE, RING_X, RING_Y = 54, -16, 16 -- ring TOPLEFT relative to button CENTER
local BG_SIZE, ICON_SIZE = 25, 20

local function PlaceRing(f, ring, bgTex, iconTex)
    local k = (f:GetWidth() or 32) / 32
    if k <= 0 then k = 1 end
    ring:ClearAllPoints()
    ring:SetSize(RING_SIZE * k, RING_SIZE * k)
    ring:SetPoint("TOPLEFT", f, "CENTER", RING_X * k, RING_Y * k)
    bgTex:ClearAllPoints()
    bgTex:SetSize(BG_SIZE * k, BG_SIZE * k)
    bgTex:SetPoint("CENTER", f, "CENTER")
    if iconTex then
        iconTex:ClearAllPoints()
        iconTex:SetSize(ICON_SIZE * k, ICON_SIZE * k)
        iconTex:SetPoint("CENTER", f, "CENTER")
    end
end

-- Round the icon off so its corners can't poke out from under the ring.
-- Returns the mask (or nil on clients without mask textures).
local function AddRoundMask(f, iconTex)
    if not (f.CreateMaskTexture and iconTex.AddMaskTexture) then return nil end
    local mask = f:CreateMaskTexture()
    mask:SetTexture(MASK_TEX, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(iconTex)
    if not pcall(iconTex.AddMaskTexture, iconTex, mask) then return nil end
    return mask
end

-- The ring texture is gold; WoW Forever's minimap buttons are bronze.
local BRONZE = { 0.86, 0.62, 0.40 }
local function TintRing(ring)
    local bronze = MBD.db and MBD.db.bronzeRings == true
    ring:SetDesaturated(bronze)
    if bronze then ring:SetVertexColor(BRONZE[1], BRONZE[2], BRONZE[3]) else ring:SetVertexColor(1, 1, 1) end
end
MBD.TintRing = TintRing

-- Pressed-in look, like Blizzard's buttons: while the mouse is held down the
-- icon sinks one pixel down-right and darkens. Works on any icon texture by
-- nudging its existing anchors, and puts everything back on release.
local pressed = {}
local function PressIcon(f, tex)
    if not tex or pressed[tex] then return end
    local pts = {}
    for i = 1, tex:GetNumPoints() do pts[i] = { tex:GetPoint(i) } end
    if #pts == 0 then return end
    local r, g, b, a = tex:GetVertexColor()
    pressed[tex] = { pts = pts, color = { r or 1, g or 1, b or 1, a or 1 } }
    local d = math.max(1, (f:GetWidth() or 32) / 32)
    tex:ClearAllPoints()
    for _, pt in ipairs(pts) do
        tex:SetPoint(pt[1], pt[2], pt[3], (pt[4] or 0) + d, (pt[5] or 0) - d)
    end
    tex:SetVertexColor((r or 1) * 0.7, (g or 1) * 0.7, (b or 1) * 0.7, a or 1)
end
local function ReleaseIcon(tex)
    local p = tex and pressed[tex]
    if not p then return end
    pressed[tex] = nil
    tex:ClearAllPoints()
    for _, pt in ipairs(p.pts) do tex:SetPoint(unpack(pt)) end
    tex:SetVertexColor(unpack(p.color))
end
MBD.PressIcon, MBD.ReleaseIcon = PressIcon, ReleaseIcon

local drawer = CreateFrame("Button", "MinimapButtonDrawerButton", Minimap)
MBD.drawerButton = drawer
drawer:SetSize(32, 32)
drawer:SetFrameStrata("MEDIUM")
drawer:SetFrameLevel(Minimap:GetFrameLevel() + 8)
drawer:RegisterForClicks("LeftButtonUp", "RightButtonUp")
drawer:RegisterForDrag("LeftButton")
drawer:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local overlay = drawer:CreateTexture(nil, "OVERLAY")
overlay:SetTexture(RING_TEX)

local bg = drawer:CreateTexture(nil, "BACKGROUND")
bg:SetTexture(BG_TEX)

local icon = drawer:CreateTexture(nil, "ARTWORK")
icon:SetTexture(DEFAULT_ICON)
icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
PlaceRing(drawer, overlay, bg, icon)
AddRoundMask(drawer, icon)
drawer.icon = icon
drawer.ring = overlay

drawer:SetScript("OnMouseDown", function(self) PressIcon(self, icon) end)
drawer:SetScript("OnMouseUp", function() ReleaseIcon(icon) end)
drawer:HookScript("OnHide", function() ReleaseIcon(icon) end)

-- Every texture that should show the drawer icon (the config window adds its own).
MBD.iconTextures = { icon }

-- Accepts a file ID ("134400"), a bare icon name ("INV_Misc_Bag_08") or a
-- full path ("Interface\\Icons\\INV_Misc_Bag_08" or with forward slashes).
function MBD:NormalizeIcon(v)
    if type(v) == "number" then return v end
    if type(v) ~= "string" then return nil end
    v = strtrim(v)
    if v == "" then return nil end
    local id = tonumber(v)
    if id then return id end
    v = v:gsub("/", "\\")
    if not v:find("\\", 1, true) then v = "Interface\\Icons\\" .. v end
    return v
end

function MBD:GetDrawerIcon()
    return self:NormalizeIcon(self.db and self.db.drawerIcon) or DEFAULT_ICON
end

function MBD:RegisterIconTexture(tex)
    tinsert(self.iconTextures, tex)
    tex:SetTexture(self:GetDrawerIcon())
end

local function MinimapIsSquare()
    return GetMinimapShape and GetMinimapShape() == "SQUARE"
end

function MBD:UpdateDrawerPosition()
    if drawer:GetParent() ~= Minimap then
        drawer:SetParent(Minimap)
        drawer:SetFrameStrata("MEDIUM")
        drawer:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    end
    local angle = math.rad(self.db.angle or 200)
    local x, y = math.cos(angle), math.sin(angle)
    local w = (Minimap:GetWidth() / 2) + 5
    local h = (Minimap:GetHeight() / 2) + 5
    if MinimapIsSquare() then
        x = math.max(-1, math.min(1, x * 1.41421))
        y = math.max(-1, math.min(1, y * 1.41421))
    end
    -- SetPoint offsets are in the drawer's own (scaled) coordinates.
    local s = drawer:GetScale()
    if not s or s <= 0 then s = 1 end
    drawer:ClearAllPoints()
    drawer:SetPoint("CENTER", Minimap, "CENTER", x * w / s, y * h / s)
end

drawer:SetScript("OnDragStart", function(self)
    if MBD.db.locked then return end
    MBD.panel:Hide()
    GameTooltip:Hide()
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        cx, cy = cx / scale, cy / scale
        MBD.db.angle = math.deg(math.atan2(cy - my, cx - mx)) % 360
        MBD:UpdateDrawerPosition()
    end)
end)
drawer:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)

drawer:SetScript("OnClick", function(_, mouse)
    if mouse == "RightButton" then
        MBD.panel:Hide()
        MBD:ToggleConfig()
    else
        MBD:TogglePanel()
    end
end)

drawer:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine(Z("Minimap Button Drawer", "小地圖按鈕收納"))
    GameTooltip:AddLine(Z("|cffffffffLeft-click|r to open the drawer", "|cffffffff左鍵|r開啟收納"), 0.8, 0.8, 0.8)
    GameTooltip:AddLine(Z("|cffffffffRight-click|r for the config menu", "|cffffffff右鍵|r開啟設定"), 0.8, 0.8, 0.8)
    if not MBD.db.locked then
        GameTooltip:AddLine(Z("|cffffffffDrag|r to move around the minimap", "|cffffffff拖曳|r可沿小地圖移動"), 0.8, 0.8, 0.8)
    end
    GameTooltip:Show()
end)
drawer:SetScript("OnLeave", GameTooltip_Hide)

--------------------------------------------------------------------------
-- Drop-down panel
--------------------------------------------------------------------------

-- The panel itself has no textures (it only holds the buttons). Its dark
-- background lives on a separate frame forced to a lower layer, so it can
-- never be drawn on top of the icons.
local panel = CreateFrame("Frame", "MinimapButtonDrawerPanel", UIParent)
MBD.panel = panel
panel:SetFrameStrata("HIGH")
panel:SetClampedToScreen(true)
panel:EnableMouse(false) -- never block clicks on the buttons
panel:SetPoint("CENTER", UIParent, "CENTER")
panel:Hide()

local panelBg = CreateFrame("Frame", nil, panel, "BackdropTemplate")
panelBg:SetAllPoints(panel)
panelBg:SetFrameStrata("MEDIUM")
panelBg:SetFrameLevel(1)
panelBg:EnableMouse(false)
tinsert(UISpecialFrames, "MinimapButtonDrawerPanel") -- Escape closes it

-- Frames for multi-band borders (one solid edge per band, nested inward).
local bandFrames = {}
local function GetBand(i)
    local f = bandFrames[i]
    if not f then
        f = CreateFrame("Frame", nil, panelBg, "BackdropTemplate")
        f:SetFrameLevel(panelBg:GetFrameLevel() + 1)
        f:EnableMouse(false)
        bandFrames[i] = f
    end
    return f
end

-- Apply the chosen background texture to the pop-out.
function MBD:ApplyPanelTexture()
    local t = self:GetPanelTexture()
    self.db.panelTexture = t.key
    for _, f in ipairs(bandFrames) do f:Hide() end
    if self.known then self:Layout() end -- padding can differ between textures
    if not t.bg then
        panelBg:SetBackdrop(nil)
        return
    end
    if t.bands then
        local inset = 0
        for _, b in ipairs(t.bands) do inset = inset + b[1] end
        panelBg:SetBackdrop({ bgFile = t.bg, tile = false,
            insets = { left = inset, right = inset, top = inset, bottom = inset } })
        panelBg:SetBackdropColor(unpack(t.color or { 1, 1, 1, 1 }))
        local off = 0
        for i, b in ipairs(t.bands) do
            local f = GetBand(i)
            f:ClearAllPoints()
            f:SetPoint("TOPLEFT", panelBg, "TOPLEFT", off, -off)
            f:SetPoint("BOTTOMRIGHT", panelBg, "BOTTOMRIGHT", -off, off)
            f:SetBackdrop({ edgeFile = WHITE_TEX, edgeSize = b[1] })
            f:SetBackdropBorderColor(b[2], b[3], b[4], 1)
            f:Show()
            off = off + b[1]
        end
        return
    end
    panelBg:SetBackdrop({
        bgFile = t.bg,
        edgeFile = t.border,
        tile = true, tileSize = t.tileSize or 16, edgeSize = t.border and 14 or 0,
        insets = t.border and { left = 3, right = 3, top = 3, bottom = 3 } or { left = 0, right = 0, top = 0, bottom = 0 },
    })
    panelBg:SetBackdropColor(unpack(t.color or { 1, 1, 1, 1 }))
    if t.border then panelBg:SetBackdropBorderColor(unpack(t.borderColor or { 1, 1, 1, 1 })) end
end

local emptyText = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
emptyText:SetPoint("CENTER")
emptyText:SetText(Z("No buttons to show.\nRight-click the drawer for options.", "目前沒有可顯示的按鈕。\n右鍵點擊收納按鈕可開啟設定。"))

-- Auto-close when the mouse has been away from the panel and drawer for a moment.
local away = 0
panel:SetScript("OnUpdate", function(self, elapsed)
    if not MBD.db.autoClose then return end
    if self:IsMouseOver(8, -8, -8, 8) or drawer:IsMouseOver() then
        away = 0
    else
        away = away + elapsed
        if away > 1.0 then self:Hide() end
    end
end)
panel:SetScript("OnShow", function() away = 0 end)

-- A closed drawer lets go of the drawer button. Minimap scanners (Node Sight) hide and
-- shrink every frame anchored to the minimap during a scan; a closed drawer still
-- anchored there would be shrunk too, and could be left invisible afterwards.
panel:HookScript("OnHide", function(self)
    self:ClearAllPoints()
    self:SetPoint("CENTER", UIParent, "CENTER")
end)

-- Returns the direction key actually in use. "AUTO" opens toward the
-- middle of the screen (the original behaviour).
function MBD:GetDirection()
    local dir = self.db and self.db.direction
    if dir and DIRECTIONS[dir] then return dir end
    local x, y = drawer:GetCenter()
    local ux, uy = UIParent:GetCenter()
    if not x or not ux then return "BOTTOMLEFT" end
    local v = (y > uy) and "BOTTOM" or "TOP"
    local hz = (x > ux) and "LEFT" or "RIGHT"
    return v .. hz
end

function MBD:SetDirection(dir)
    self.db.direction = (dir and DIRECTIONS[dir]) and dir or "AUTO"
    self:Layout()
    if panel:IsShown() then self:AnchorPanel() end
end

function MBD:AnchorPanel()
    panel:ClearAllPoints()
    if not drawer:GetCenter() then
        panel:SetPoint("TOPRIGHT", Minimap, "BOTTOMRIGHT", 0, -6)
        return
    end
    local d = DIRECTIONS[self:GetDirection()]
    panel:SetPoint(d.point, drawer, d.rel, d.x, d.y)
end

-- Apply the drawer button's size and icon settings.
function MBD:ApplyDrawerStyle()
    local db = self.db
    local size = tonumber(db.drawerSize) or DEFAULTS.drawerSize
    size = math.max(SIZE_MIN, math.min(SIZE_MAX, size))
    db.drawerSize = size
    size = math.floor(size / 2 + 0.5) * 2 -- even sizes, like the icon size option
    db.drawerSize = size
    self.drawerScale = size / DRAWER_BASE
    drawer:SetScale(self.drawerScale)

    local tex = self:GetDrawerIcon()
    for _, t in ipairs(self.iconTextures) do t:SetTexture(tex) end
    TintRing(drawer.ring)

    self:UpdateDrawerPosition()
    if panel:IsShown() then self:AnchorPanel() end
end

--------------------------------------------------------------------------
-- Self-repair: addons that scan the minimap (Node Sight) hide everything on
-- it for a moment (alpha 0, tiny scale, no clicks) and put it back after.
-- If that restore misses or saves the wrong value, the drawer button stops
-- taking clicks or the drawer opens invisibly. Put our own frames back.
--------------------------------------------------------------------------

local function MouseOff(f)
    if f.IsMouseClickEnabled and f.IsMouseMotionEnabled then
        return not f:IsMouseClickEnabled() or not f:IsMouseMotionEnabled()
    end
    return f.IsMouseEnabled and not f:IsMouseEnabled() or false
end

local function MouseOn(f)
    if f.SetMouseClickEnabled and f.SetMouseMotionEnabled then
        f:SetMouseClickEnabled(true)
        f:SetMouseMotionEnabled(true)
    else
        f:EnableMouse(true)
    end
end

local function Off(v, want)
    return type(v) ~= "number" or math.abs(v - want) > 0.01
end

function MBD:NeedsRepair()
    if Off(drawer:GetAlpha(), 1) or Off(drawer:GetScale(), self.drawerScale or 1) or MouseOff(drawer) then
        return true
    end
    if Off(panel:GetAlpha(), 1) or Off(panel:GetScale(), 1) then return true end
    if panel:IsShown() then
        for _, name in ipairs(self.order) do
            local f = self.buttons[name]
            if f and f:IsShown() and MouseOff(f) then return true end
        end
    end
    return false
end

function MBD:Repair()
    drawer:SetAlpha(1)
    drawer:SetScale(self.drawerScale or 1)
    MouseOn(drawer)
    panel:SetAlpha(1)
    panel:SetScale(1)
    for _, name in ipairs(self.order) do
        local f = self.buttons[name]
        if f and not (self.db and self.db.hidden[name]) then MouseOn(f) end
    end
    if self.db then self:UpdateDrawerPosition() end
end

-- Checked twice a second. A scan only takes a moment, so a frame is put back
-- only once it has been wrong for a while (longer while the minimap itself is
-- still switched off, which means a scan is probably still running).
do
    local watch = CreateFrame("Frame")
    local tick, wrongSince = 0, nil
    local WAIT, WAIT_BUSY = 4, 15
    watch:SetScript("OnUpdate", function(_, elapsed)
        tick = tick + elapsed
        if tick < 0.5 then return end
        tick = 0
        if not MBD.db or drawer:GetScript("OnUpdate") then return end -- not loaded / being dragged
        if not MBD:NeedsRepair() then wrongSince = nil return end
        local now = GetTime()
        wrongSince = wrongSince or now
        local busy = Minimap.IsMouseClickEnabled and not Minimap:IsMouseClickEnabled()
        if now - wrongSince >= (busy and WAIT_BUSY or WAIT) then
            wrongSince = nil
            MBD:Repair()
        end
    end)
end

function MBD:TogglePanel()
    if panel:IsShown() then
        panel:Hide()
    else
        if self:NeedsRepair() then self:Repair() end
        self:Scan()
        self:Layout()
        self:AnchorPanel()
        panel:Show()
    end
end

--------------------------------------------------------------------------
-- Capturing buttons
--------------------------------------------------------------------------

local noop = function() end

local function Capture(name, f)
    if MBD.buttons[name] then return end
    MBD.buttons[name] = f

    if not hooked[f] then
        hooked[f] = true
        orig[f] = {
            SetPoint = f.SetPoint, ClearAllPoints = f.ClearAllPoints,
            SetParent = f.SetParent, Point = f:GetNumPoints() > 0 and { f:GetPoint(1) } or nil,
            parent = f:GetParent(),
            scale = f:GetScale(),
            level = f:GetFrameLevel(),
            movable = f:IsMovable(),
            -- the addon's own drag handlers, restored when the button is released
            dragStart = f:HasScript("OnDragStart") and f:GetScript("OnDragStart") or nil,
            dragStop = f:HasScript("OnDragStop") and f:GetScript("OnDragStop") or nil,
        }

        -- Keep hidden buttons hidden even if their addon calls :Show().
        hooksecurefunc(f, "Show", function(self)
            if MBD.panelOwns and MBD.panelOwns[self] == false then self:Hide() end
        end)

        -- Pressed-in look while the mouse is held down on the button.
        if f:HasScript("OnMouseDown") then
            f:HookScript("OnMouseDown", function(self)
                if MBD.buttons[self:GetName() or ""] then PressIcon(self, MBD:GetButtonIcon(self)) end
            end)
            f:HookScript("OnMouseUp", function(self) ReleaseIcon(MBD:GetButtonIcon(self)) end)
            f:HookScript("OnHide", function(self) ReleaseIcon(MBD:GetButtonIcon(self)) end)
        end

        -- Optionally close the drawer after the button is clicked.
        if f:HasScript("OnClick") then
            f:HookScript("OnClick", function()
                if MBD.db.closeOnClick then
                    C_Timer.After(0, function() panel:Hide() end)
                end
            end)
        end
    end

    -- While in the drawer, the button shouldn't be draggable back out.
    f:SetMovable(false)
    if f.RegisterForDrag then f:RegisterForDrag() end
    if f:HasScript("OnDragStart") then f:SetScript("OnDragStart", nil) end
    if f:HasScript("OnDragStop") then f:SetScript("OnDragStop", nil) end

    orig[f].SetParent(f, panel)
    f.SetPoint = noop
    f.ClearAllPoints = noop
    f.SetParent = noop
    f:SetFrameStrata("HIGH")
end

--------------------------------------------------------------------------
-- Uniform skin: every collected button gets the same ring, background and
-- icon size, whatever art its addon gave it. Fully undone on release.
--------------------------------------------------------------------------

local DECOR_IDS = { [136430] = true, [136467] = true, [136477] = true } -- ring, background, highlight
local skins = {}

local function TexPath(r)
    local atlas = r.GetAtlas and r:GetAtlas()
    if atlas and atlas ~= "" then return atlas end
    return r:GetTexture()
end

-- Ring / background art by name. A path under Interface\Icons is always a real icon.
local function IsDecorPath(t)
    if type(t) == "number" then return DECOR_IDS[t] or false end
    if type(t) ~= "string" then return false end
    t = t:lower()
    if t:find("\\icons\\", 1, true) then return false end
    return (t:find("border", 1, true) or t:find("background", 1, true) or t:find("ring", 1, true)
        or t:find("circle", 1, true) or t:find("minimap\\", 1, true) or t:find("overlay", 1, true)) and true or false
end

-- Every texture on the button and on its direct child frames.
local function AllTextures(f)
    local list = {}
    for _, r in ipairs({ f:GetRegions() }) do
        if r:GetObjectType() == "Texture" then tinsert(list, r) end
    end
    for _, child in ipairs({ f:GetChildren() }) do
        for _, r in ipairs({ child:GetRegions() }) do
            if r:GetObjectType() == "Texture" then tinsert(list, r) end
        end
    end
    return list
end

-- Pick the texture that is the button's icon: score every candidate rather
-- than trusting one field, so ring art never wins and icons in unusual
-- layers or child frames are still found.
local function FindIcon(f, s)
    local w = f:GetWidth() or 32
    local normal = f.GetNormalTexture and f:GetNormalTexture()
    local best, bestScore
    for _, r in ipairs(AllTextures(f)) do
        if r ~= (s and s.ring) and r ~= (s and s.bg) and r:GetDrawLayer() ~= "HIGHLIGHT" then
            local t = TexPath(r)
            if t then
                local score = 0
                if r == f.icon or r == f.Icon then score = score + 60 end
                if IsDecorPath(t) then score = score - 100 end
                if type(t) == "string" and t:lower():find("\\icons\\", 1, true) then score = score + 25 end
                if type(t) == "number" then score = score + 10 end
                local layer = r:GetDrawLayer()
                if layer == "ARTWORK" then score = score + 15
                elseif layer == "BORDER" then score = score + 8
                elseif layer == "BACKGROUND" then score = score - 5 end
                if r == normal then score = score + 5 end
                if r:GetParent() ~= f then score = score - 5 end
                local rw = r:GetWidth() or 0
                if rw > w * 1.2 then score = score - 60          -- bigger than the button: a ring
                elseif rw >= w * 0.35 then score = score + 10 end -- icon-sized
                if not r:IsShown() then score = score - 30 end
                if not bestScore or score > bestScore then best, bestScore = r, score end
            end
        end
    end
    if best and bestScore > -20 then return best end
end

function MBD:GetButtonIcon(f)
    local s = skins[f]
    if s and s.active then return s.icon end
    return FindIcon(f)
end

-- Keep hidden art hidden even if its addon sets the alpha again.
local alphaHooked = {}
local function HideArt(s, r)
    if s.hidden[r] ~= nil then return end
    s.hidden[r] = r:GetAlpha()
    s.hiding[r] = true
    if not alphaHooked[r] then
        alphaHooked[r] = true
        hooksecurefunc(r, "SetAlpha", function(self, a)
            local owner = alphaHooked[self]
            if type(owner) == "table" and owner.hiding[self] and a ~= 0 then
                owner.hidden[self] = a  -- remember what the addon wanted, for later
                self:SetAlpha(0)
            end
        end)
    end
    alphaHooked[r] = s
    r:SetAlpha(0)
end

function MBD:SkinButton(f)
    local w = f:GetWidth()
    if not w or w <= 0 then return end
    local s = skins[f]
    if not s then
        s = { hidden = {}, hiding = {} }
        s.ring = f:CreateTexture(nil, "OVERLAY", nil, 7)
        s.ring:SetTexture(RING_TEX)
        s.bg = f:CreateTexture(nil, "BACKGROUND", nil, -8)
        s.bg:SetTexture(BG_TEX)
        s.ring:Hide(); s.bg:Hide()
        skins[f] = s
    end
    if not s.active then
        local ic = FindIcon(f, s)
        if not ic then return end -- can't tell what the icon is: leave this button's own art alone
        s.active = true
        s.icon = ic
        s.iconPoints = {}
        for i = 1, ic:GetNumPoints() do s.iconPoints[i] = { ic:GetPoint(i) } end
        s.iconW, s.iconH = ic:GetSize()
        s.iconParent = ic:GetParent()
        if not s.mask or s.maskFor ~= ic then
            s.mask, s.maskFor = AddRoundMask(f, ic), ic
            s.masked = s.mask and true or false
        elseif not s.masked then
            s.masked = pcall(ic.AddMaskTexture, ic, s.mask)
        end
    end
    -- Hide every other piece of art: all textures on the button itself, and
    -- anything on child frames that is button-sized or bigger (rings, backdrops).
    -- Highlights stay. Re-checked every time, in case the addon added art since.
    local pushed = f.GetPushedTexture and f:GetPushedTexture()
    local iconIsNormal = f.GetNormalTexture and f:GetNormalTexture() == s.icon
    for _, r in ipairs(AllTextures(f)) do
        if r ~= s.icon and r ~= s.ring and r ~= s.bg and r:GetDrawLayer() ~= "HIGHLIGHT"
            and not (iconIsNormal and r == pushed) then
            if r:GetParent() == f or (r:GetWidth() or 0) >= w * 0.9 then
                HideArt(s, r)
            end
        end
    end
    PlaceRing(f, s.ring, s.bg, s.icon)
    -- a Button swaps its normal texture for the pushed one while held: keep them identical
    if iconIsNormal and pushed and pushed ~= s.icon then
        pushed:ClearAllPoints()
        pushed:SetAllPoints(s.icon)
    end
    TintRing(s.ring)
    s.ring:Show()
    s.bg:Show()
end

function MBD:UnskinButton(f)
    local s = skins[f]
    if not s or not s.active then return end
    s.active = false
    s.ring:Hide()
    s.bg:Hide()
    local ic = s.icon
    if ic then ReleaseIcon(ic) end
    for r, a in pairs(s.hidden) do
        s.hiding[r] = nil
        r:SetAlpha(a)
    end
    wipe(s.hidden)
    if ic then
        if s.masked then pcall(ic.RemoveMaskTexture, ic, s.mask); s.masked = false end
        ic:ClearAllPoints()
        for _, pt in ipairs(s.iconPoints or {}) do ic:SetPoint(unpack(pt)) end
        if s.iconW and s.iconW > 0 then ic:SetSize(s.iconW, s.iconH) end
    end
end

-- Re-tint every ring after the colour option changes.
function MBD:RefreshRings()
    TintRing(drawer.ring)
    for _, s in pairs(skins) do
        if s.active then TintRing(s.ring) end
    end
end

local function Release(f)
    local o = orig[f]
    if not o then return end
    MBD:UnskinButton(f)
    f.SetPoint, f.ClearAllPoints, f.SetParent = o.SetPoint, o.ClearAllPoints, o.SetParent
    f:SetParent(o.parent or Minimap)
    f:SetFrameStrata("MEDIUM")
    f:SetScale(o.scale or 1)
    f:ClearAllPoints()
    if o.Point then
        f:SetPoint(unpack(o.Point))
    else
        f:SetPoint("CENTER", Minimap, "CENTER")
    end
    if o.level then f:SetFrameLevel(o.level) end
    f:SetAlpha(1)

    -- Give the addon back its own drag handling so it can be moved on the minimap again.
    f:SetMovable(o.movable ~= false)
    if f.RegisterForDrag then f:RegisterForDrag("LeftButton") end
    if f:HasScript("OnDragStart") then f:SetScript("OnDragStart", o.dragStart) end
    if f:HasScript("OnDragStop") then f:SetScript("OnDragStop", o.dragStop) end

    -- LibDBIcon buttons: let the library put it back at its saved minimap angle.
    local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
    local name = f:GetName()
    if LDBIcon and name and name:find("^LibDBIcon10_") and LDBIcon.Refresh then
        pcall(LDBIcon.Refresh, LDBIcon, (name:gsub("^LibDBIcon10_", "")))
    end
    f:Show()
end

function MBD:ReleaseButton(name)
    local f = self.buttons[name]
    if not f then return end
    self.buttons[name] = nil
    if self.panelOwns then self.panelOwns[f] = nil end
    Release(f)
end

function MBD:Scan()
    -- LibDBIcon-based buttons (the vast majority of addons)
    local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
    if LDBIcon and LDBIcon.GetButtonList then
        for _, ldbName in ipairs(LDBIcon:GetButtonList()) do
            local f = LDBIcon:GetMinimapButton(ldbName)
            if f and f:GetName() then
                local name = f:GetName()
                if not self.db.ignored[name] then Capture(name, f) end
                self.known[name] = true
            end
        end
    end

    -- Hand-made buttons parented to the minimap or its cluster
    -- (retail keeps the minimap inside MinimapCluster.MinimapContainer)
    local container = MinimapCluster and MinimapCluster.MinimapContainer
    local parents = { Minimap, MinimapBackdrop, MinimapCluster, container }
    for i = 1, 4 do
        local p = parents[i]
        if p then
            for _, child in ipairs({ p:GetChildren() }) do
                if child ~= drawer and LooksLikeButton(child) then
                    local name = child:GetName()
                    self.known[name] = true
                    if not self.db.ignored[name] then Capture(name, child) end
                end
            end
        end
    end

    self:UpdateOrder()
    if self.RefreshOptions then self:RefreshOptions() end
end

-- db.order holds every known button in the user's chosen order. New buttons
-- are appended alphabetically; self.order is the subset currently collected.
function MBD:UpdateOrder()
    local db = self.db
    local inOrder, clean = {}, {}
    for _, name in ipairs(db.order) do
        if not inOrder[name] then inOrder[name] = true; tinsert(clean, name) end
    end
    local new = {}
    for name in pairs(self.known) do
        if not inOrder[name] then tinsert(new, name) end
    end
    table.sort(new, function(a, b) return self:PrettyName(a):lower() < self:PrettyName(b):lower() end)
    for _, name in ipairs(new) do tinsert(clean, name) end
    db.order = clean

    wipe(self.order)
    for _, name in ipairs(db.order) do
        if self.buttons[name] then tinsert(self.order, name) end
    end
end

-- The list shown in the config: known buttons in user order.
function MBD:GetConfigList()
    local list = {}
    for _, name in ipairs(self.db.order) do
        if self.known[name] then tinsert(list, name) end
    end
    return list
end

-- Move a button from one position in the config list to another.
function MBD:MoveButton(fromIndex, toIndex)
    local list = self:GetConfigList()
    if fromIndex == toIndex or not list[fromIndex] then return end
    local name = tremove(list, fromIndex)
    tinsert(list, math.max(1, math.min(#list + 1, toIndex)), name)
    -- keep any saved-but-not-currently-loaded names at the end
    local inList = {}
    for _, n in ipairs(list) do inList[n] = true end
    for _, n in ipairs(self.db.order) do
        if not inList[n] then tinsert(list, n) end
    end
    self.db.order = list
    self:UpdateOrder()
    self:Layout()
end

function MBD:Layout()
    self.panelOwns = self.panelOwns or {}
    local db = self.db
    local size, gap, cols = db.buttonSize, db.spacing, math.max(1, db.columns)
    local pad = self:GetPanelPad()
    local i = 0

    -- When the drop-down opens upward, the first row sits next to the drawer
    -- button and further rows stack upward.
    local visible = 0
    for _, name in ipairs(self.order) do
        if self.buttons[name] and not db.hidden[name] then visible = visible + 1 end
    end
    local totalRows = math.max(1, math.ceil(visible / cols))
    local growUp = DIRECTIONS[self:GetDirection()].up

    for _, name in ipairs(self.order) do
        local f = self.buttons[name]
        local o = orig[f]
        if f and o then
            o.ClearAllPoints(f)
            if db.hidden[name] then
                self.panelOwns[f] = false
                f:Hide()
            else
                self.panelOwns[f] = true
                local col = i % cols
                local row = math.floor(i / cols)
                if growUp then row = totalRows - 1 - row end
                local fw = f:GetWidth()
                local scale = (fw and fw > 0) and (size / fw) or 1
                f:SetScale(scale)
                -- Offsets are in the button's own (scaled) coordinate space.
                local cx = (pad + col * (size + gap) + size / 2) / scale
                local cy = (pad + row * (size + gap) + size / 2) / scale
                o.SetPoint(f, "CENTER", panel, "TOPLEFT", cx, -cy)
                f:SetAlpha(1) -- LibDBIcon "fade out" buttons would otherwise be invisible
                if db.uniformStyle then self:SkinButton(f) else self:UnskinButton(f) end
                -- Sit every button above the panel so the panel can't swallow its clicks.
                f:SetFrameStrata("DIALOG")
                f:SetFrameLevel(panel:GetFrameLevel() + 10)
                f:EnableMouse(true)
                -- Undo any dimming/greying the owning addon left on the icon.
                local iconTex = f.icon or f.Icon
                if type(iconTex) == "table" and iconTex.SetVertexColor then
                    iconTex:SetVertexColor(1, 1, 1, 1)
                    if iconTex.SetDesaturated then iconTex:SetDesaturated(false) end
                    iconTex:SetAlpha(1)
                end
                for _, r in ipairs({ f:GetRegions() }) do
                    if r.GetDrawLayer and r:GetDrawLayer() == "ARTWORK" and r.SetDesaturated then
                        r:SetDesaturated(false)
                        r:SetAlpha(1)
                    end
                end
                f:Show()
                i = i + 1
            end
        end
    end

    local usedCols = math.min(cols, math.max(i, 1))
    local rows = math.max(1, math.ceil(i / cols))
    if i == 0 then
        emptyText:Show()
        panel:SetSize(220, 50)
    else
        emptyText:Hide()
        panel:SetSize(2 * pad + usedCols * size + (usedCols - 1) * gap,
                      2 * pad + rows * size + (rows - 1) * gap)
    end
end

--------------------------------------------------------------------------
-- Init
--------------------------------------------------------------------------

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = type(dst[k]) == "table" and dst[k] or {}
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
    return dst
end

MBD:RegisterEvent("ADDON_LOADED")
MBD:RegisterEvent("PLAYER_ENTERING_WORLD")
MBD:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        MinimapButtonDrawerDB = CopyDefaults(DEFAULTS, MinimapButtonDrawerDB or {})
        self.db = MinimapButtonDrawerDB
        self.db.undocked, self.db.freePos = nil, nil -- option removed
        -- 1.3.6: bronze rings is off by default, including for existing settings
        if (self.db.dbVersion or 0) < 3 then
            self.db.bronzeRings = false
            self.db.dbVersion = 3
        end
        -- 1.3.7: the drawer button size is now in pixels (was a percentage),
        -- and both sizes start at 32, the size of an uncollected minimap button.
        if (self.db.dbVersion or 0) < 4 then
            self.db.drawerSize = DEFAULTS.drawerSize
            self.db.buttonSize = DEFAULTS.buttonSize
            self.db.dbVersion = 4
        end
        self:ApplyPanelTexture()
        self.known = {}
        self:ApplyDrawerStyle()
        if self.CreateOptions then self:CreateOptions() end

        -- Retail's Edit Mode can resize or move the minimap: keep the drawer
        -- button on its edge and the open drawer next to it.
        Minimap:HookScript("OnSizeChanged", function()
            self:UpdateDrawerPosition()
            if panel:IsShown() then self:AnchorPanel() end
        end)
        if EventRegistry and EventRegistry.RegisterCallback then
            pcall(EventRegistry.RegisterCallback, EventRegistry, "EditMode.Exit", function()
                self:UpdateDrawerPosition()
            end, self)
        end

        -- Catch LibDBIcon buttons created after we load
        local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
        if LDBIcon and LDBIcon.RegisterCallback then
            LDBIcon.RegisterCallback(self, "LibDBIcon_IconCreated", function()
                C_Timer.After(0.1, function() self:Scan(); self:Layout() end)
            end)
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Addons create buttons at different times, so sweep a few times.
        for _, t in ipairs({ 0.5, 3, 8 }) do
            C_Timer.After(t, function() self:Scan(); self:Layout() end)
        end
        self:UpdateDrawerPosition()
    end
end)

--------------------------------------------------------------------------
-- Addon Compartment (the retail minimap's addon list): an entry that works
-- like the drawer button, for when it's hidden or hard to reach.
--------------------------------------------------------------------------

function MinimapButtonDrawer_OnAddonCompartmentClick(_, mouse)
    if not MBD.db then return end
    -- 10.x passes the mouse button; 11.0+ passes a table holding it
    if type(mouse) == "table" then mouse = mouse.buttonName end
    if mouse == "RightButton" then
        panel:Hide()
        MBD:ToggleConfig()
    else
        MBD:TogglePanel()
    end
end

function MinimapButtonDrawer_OnAddonCompartmentEnter(_, frame)
    if type(frame) ~= "table" or not frame.GetObjectType then frame = AddonCompartmentFrame end
    if not frame then return end
    GameTooltip:SetOwner(frame, "ANCHOR_LEFT")
    GameTooltip:AddLine(Z("Minimap Button Drawer", "小地圖按鈕收納"))
    GameTooltip:AddLine(Z("|cffffffffLeft-click|r to open the drawer", "|cffffffff左鍵|r開啟收納"), 0.8, 0.8, 0.8)
    GameTooltip:AddLine(Z("|cffffffffRight-click|r for the config menu", "|cffffffff右鍵|r開啟設定"), 0.8, 0.8, 0.8)
    GameTooltip:Show()
end

function MinimapButtonDrawer_OnAddonCompartmentLeave()
    GameTooltip:Hide()
end

SLASH_MINIMAPBUTTONDRAWER1 = "/mbd"
SLASH_MINIMAPBUTTONDRAWER2 = "/minimapdrawer"
SlashCmdList.MINIMAPBUTTONDRAWER = function(msg)
    msg = (msg or ""):lower()
    if msg == "rescan" then
        MBD:Repair()
        MBD:Scan(); MBD:Layout()
        print(Z("|cff33ff99Minimap Button Drawer|r: found ", "|cff33ff99小地圖按鈕收納|r：找到 ") .. #MBD.order .. Z(" buttons.", " 個按鈕。"))
    elseif msg == "reset" then
        MBD.db.angle = DEFAULTS.angle
        MBD.db.locked = false
        MBD.db.direction = DEFAULTS.direction
        MBD.db.drawerSize = DEFAULTS.drawerSize
        MBD:ApplyDrawerStyle()
        if MBD.panel:IsShown() then MBD:Layout(); MBD:AnchorPanel() end
        if MBD.RefreshConfig then MBD:RefreshConfig() end
        print(Z("|cff33ff99Minimap Button Drawer|r: drawer button reset to the minimap.", "|cff33ff99小地圖按鈕收納|r：按鈕已移回小地圖。"))
    else
        MBD:ToggleConfig()
    end
end

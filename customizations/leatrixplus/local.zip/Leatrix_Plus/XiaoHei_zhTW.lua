-- Local Traditional Chinese additions, separate from author locale files.
local _, addon = ...
local locale = GetLocale()
local choices = {"enUS", "deDE", "esES", "esMX", "frFR", "itIT", "ptBR", "ruRU", "koKR", "zhCN", "zhTW"}
local choice = LeaPlusDB and LeaPlusDB.AddonLanguage
if type(choice) == "number" and choices[choice - 1] then locale = choices[choice - 1] end
if locale ~= "zhTW" then return end
local L = addon.L
L["Start here."] = "從這裡開始。"
L["Step 1"] = "步驟一"
L["WoW Forever"] = "魔獸世界：永恆"
L["Deutsch"] = "德文"
L["English"] = "英文"
L["Español (AL)"] = "西班牙文（拉丁美洲）"
L["Español (EU)"] = "西班牙文（歐洲）"
L["Français"] = "法文"
L["Italiano"] = "義大利文"
L["Português"] = "葡萄牙文"

-- Local Traditional Chinese additions; author locale files remain unchanged.
if GetLocale() ~= "zhTW" then return end
local L = LibStub("AceLocale-3.0"):GetLocale("GatherMate2", true)
if not L then return end
L["Icon alpha value, this lets you change the transparency of the icons. Only applies on Minimap."] = "設定圖示的透明度，僅套用於小地圖。"
L["Minimap Icon Alpha"] = "小地圖圖示透明度"
L["World Map Icon Alpha"] = "世界地圖圖示透明度"
